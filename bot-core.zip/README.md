# Novo BOT

Base simples para rodar um assistente de WhatsApp no Termux usando Baileys e Gemini API.

## Instalar no Termux

```bash
pkg update && pkg upgrade -y
pkg install nodejs git -y
npm install
```

## Rodar

```bash
npm start
```

Na primeira execucao, leia o QR Code pelo WhatsApp:

`WhatsApp > Aparelhos conectados > Conectar um aparelho`

## Manter ativo no S20 FE

No Android:

`Configuracoes > Aplicativos > Termux > Bateria > Sem restricoes`

No Termux:

```bash
termux-wake-lock
```

## Rodar com PM2

```bash
npm install -g pm2
pm2 start src/index.js --name novo-bot
pm2 start src/web.js --name novo-bot-web
pm2 monit
pm2 save
```

Para parar:

```bash
pm2 stop novo-bot
```

## Gerenciador web

O painel roda na porta `3000` por padrao:

```bash
npm run web
```

Com PM2:

```bash
pm2 start src/web.js --name novo-bot-web
```

No Tailscale, acesse:

`http://100.69.30.66:3000`

O painel mostra status do processo, QR Code ativo, logs recentes e botoes para iniciar, parar, reiniciar e salvar o PM2.

## Onde editar

- `src/handlers/menu.js`: mensagem do menu principal.
- `src/handlers/ia.js`: fluxo com Gemini API.
- `src/index.js`: roteamento entre privado, grupos e IA.

## Integracao com Gemini API

Crie um arquivo `.env` na raiz do projeto ou defina a chave no Termux antes de iniciar o bot:

```bash
export GEMINI_API_KEY="sua_chave_aqui"
export GEMINI_MODEL="gemini-2.0-flash"
pm2 restart novo-bot --update-env
pm2 restart novo-bot-web --update-env
pm2 save
```

Exemplo de `.env`:

```env
GEMINI_API_KEY=sua_chave_aqui
GEMINI_MODEL=gemini-2.0-flash
GOOGLE_SEARCH_API_KEY=sua_chave_google_custom_search
GOOGLE_SEARCH_CX=seu_search_engine_id
```

Fallback de busca web quando a Gemini falhar:

- `GOOGLE_SEARCH_API_KEY`: chave da API Google Custom Search JSON.
- `GOOGLE_SEARCH_CX`: ID do mecanismo de pesquisa personalizado.

Quando configurado, se a Gemini falhar por cota/erro, o bot tenta buscar no Google e responde direto com o melhor resultado.

No privado, envie qualquer mensagem. Em grupos, comece com `ia`, `bot` ou `gemini`, por exemplo:

```text
ia crie uma resposta para cliente perguntando preco
```

Quando a Gemini ficar sem cota ou indisponivel, o bot responde com o modo offline. Ele aprende automaticamente respostas boas vindas da IA online e tambem pode ser ensinado manualmente:

```text
aprenda: qual o horario de atendimento => Atendemos de segunda a sexta, das 8h as 18h.
```

## Boss Status Divolion

Envie `!boss` para buscar a lista atual em `https://divolion.net/?page=boss`.

Tambem da para filtrar:

```text
!boss epic
!boss raid
```

Alertas automaticos no chat atual:

```text
!bossalert on
!bossalert status
!bossalert off
```

Com os alertas ativos, o bot avisa quando faltar 1 hora para um boss nascer no dia atual, repete a cada 20 minutos e avisa quando o site mostrar o boss como vivo.

## Sessao

O login fica salvo em `auth_info/`. Nao apague essa pasta se nao quiser ler o QR Code de novo.

Se trocar de numero ou quiser refazer login, pare o bot e apague `auth_info/`.
