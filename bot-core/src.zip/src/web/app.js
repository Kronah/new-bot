"use strict";

const state = {
  activeLog: "out",
  replyToId: null,
  inboxMessages: [],
  correctionTimer: null,
  autoCorrectionTimer: null,
  autoCorrecting: false,
  lastCorrectedText: "",
  activeView: "overview",
  groupUpdateInFlight: false,
  iaConfigDirty: false,
  iaConfigLoaded: false
};

state.eventsImageDataUrl = "";

const elements = {
  processStatus: document.getElementById("processStatus"),
  connection: document.getElementById("connection"),
  pm2: document.getElementById("pm2"),
  memory: document.getElementById("memory"),
  cpu: document.getElementById("cpu"),
  deviceConnection: document.getElementById("deviceConnection"),
  deviceProcess: document.getElementById("deviceProcess"),
  deviceMemory: document.getElementById("deviceMemory"),
  deviceCpu: document.getElementById("deviceCpu"),
  deviceCollectedAt: document.getElementById("deviceCollectedAt"),
  deviceDetails: document.getElementById("deviceDetails"),
  gemini: document.getElementById("gemini"),
  geminiModel: document.getElementById("geminiModel"),
  geminiQuota: document.getElementById("geminiQuota"),
  updatedAt: document.getElementById("updatedAt"),
  qrState: document.getElementById("qrState"),
  qrBox: document.getElementById("qrBox"),
  actionOutput: document.getElementById("actionOutput"),
  logs: document.getElementById("logs"),
  clearLogsButton: document.getElementById("clearLogsButton"),
  groupsList: document.getElementById("groupsList"),
  personalityGrid: document.getElementById("personalityGrid"),
  iaCustomPrompt: document.getElementById("iaCustomPrompt"),
  iaScheduleEnabled: document.getElementById("iaScheduleEnabled"),
  iaScheduleStart: document.getElementById("iaScheduleStart"),
  iaScheduleEnd: document.getElementById("iaScheduleEnd"),
  iaScheduleSelected: document.getElementById("iaScheduleSelected"),
  iaSchedulePrompt: document.getElementById("iaSchedulePrompt"),
  iaGroupProfiles: document.getElementById("iaGroupProfiles"),
  iaAdminProfiles: document.getElementById("iaAdminProfiles"),
  iaActiveLabel: document.getElementById("iaActiveLabel"),
  iaConfigStatus: document.getElementById("iaConfigStatus"),
  saveIaConfigButton: document.getElementById("saveIaConfigButton"),
  adminForm: document.getElementById("adminForm"),
  adminName: document.getElementById("adminName"),
  adminPhone: document.getElementById("adminPhone"),
  adminStatus: document.getElementById("adminStatus"),
  adminsList: document.getElementById("adminsList"),
  refreshAdminsButton: document.getElementById("refreshAdminsButton"),
  chatGroupSelect: document.getElementById("chatGroupSelect"),
  chatMessage: document.getElementById("chatMessage"),
  suggestionsPanel: document.getElementById("suggestionsPanel"),
  correctChatButton: document.getElementById("correctChatButton"),
  sendChatButton: document.getElementById("sendChatButton"),
  chatStatus: document.getElementById("chatStatus"),
  refreshInboxButton: document.getElementById("refreshInboxButton"),
  inboxList: document.getElementById("inboxList"),
  replyPreview: document.getElementById("replyPreview"),
  replyAuthor: document.getElementById("replyAuthor"),
  replyText: document.getElementById("replyText"),
  clearReplyButton: document.getElementById("clearReplyButton"),
  outboxList: document.getElementById("outboxList"),
  refreshButton: document.getElementById("refreshButton"),
  refreshGroupsButton: document.getElementById("refreshGroupsButton"),
  eventsGroupSelect: document.getElementById("eventsGroupSelect"),
  eventsEventAt: document.getElementById("eventsEventAt"),
  eventsNotifyBefore: document.getElementById("eventsNotifyBefore"),
  eventsRepeat: document.getElementById("eventsRepeat"),
  eventsText: document.getElementById("eventsText"),
  eventsImage: document.getElementById("eventsImage"),
  eventsImageFile: document.getElementById("eventsImageFile"),
  eventsAddButton: document.getElementById("eventsAddButton"),
  eventsStatus: document.getElementById("eventsStatus"),
  eventsList: document.getElementById("eventsList"),
  refreshEventsButton: document.getElementById("refreshEventsButton"),
  copyStatus: document.getElementById("copyStatus")
};

elements.refreshButton.addEventListener("click", refreshAll);
elements.refreshGroupsButton.addEventListener("click", refreshGroups);
if (elements.refreshEventsButton) elements.refreshEventsButton.addEventListener("click", refreshEvents);
elements.saveIaConfigButton.addEventListener("click", saveIaConfig);
elements.refreshAdminsButton.addEventListener("click", refreshAdmins);
elements.adminForm.addEventListener("submit", addAdminFromForm);
elements.sendChatButton.addEventListener("click", sendChatMessage);
elements.correctChatButton.addEventListener("click", correctChatText);
elements.refreshInboxButton.addEventListener("click", refreshInbox);
elements.clearReplyButton.addEventListener("click", clearReplySelection);
elements.chatGroupSelect.addEventListener("change", () => {
  clearReplySelection();
  refreshInbox();
});
elements.chatMessage.addEventListener("input", handleChatMessageInput);
if (elements.eventsGroupSelect) {
  elements.eventsGroupSelect.addEventListener("change", () => {
    loadEventReminders(elements.eventsGroupSelect.value);
  });
}
if (elements.eventsAddButton) elements.eventsAddButton.addEventListener("click", createEventReminder);
if (elements.eventsImageFile) {
  elements.eventsImageFile.addEventListener("change", handleEventsImageFileChange);
}

document.querySelectorAll("[data-view-target]").forEach((button) => {
  button.addEventListener("click", () => {
    showView(button.dataset.viewTarget);
    document.querySelectorAll("[data-view-target]").forEach((item) => item.classList.remove("active"));
    button.classList.add("active");
  });
});

document.querySelectorAll("[data-copy]").forEach((button) => {
  button.addEventListener("click", async () => {
    const command = button.dataset.copy;

    try {
      await copyText(command);
      elements.copyStatus.textContent = `Copiado: ${command}`;
      document.querySelectorAll("[data-copy]").forEach((item) => item.classList.remove("copied"));
      button.classList.add("copied");
    } catch (error) {
      elements.copyStatus.textContent = command;
    }

    setTimeout(() => {
      elements.copyStatus.textContent = "Clique para copiar";
      button.classList.remove("copied");
    }, 2200);
  });
});

document.querySelectorAll("[data-action]").forEach((button) => {
  button.addEventListener("click", async () => {
    const action = button.dataset.action;
    elements.actionOutput.textContent = `Executando ${action}...`;

    try {
      if (action === "disconnect") {
        const message = await runDisconnectFlow();
        elements.actionOutput.textContent = message;
      } else {
        const response = await fetch(`/api/actions/${action}`, { method: "POST" });
        const data = await response.json();
        elements.actionOutput.textContent = data.output || data.error || "Concluido.";
      }
    } catch (error) {
      elements.actionOutput.textContent = error.message;
    }

    setTimeout(refreshAll, 800);
  });
});

async function runDisconnectFlow() {
  await fetch("/api/actions/stop", { method: "POST" });

  await fetch("/api/code-delete", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ path: "auth_info" })
  });

  await fetch("/api/code-folder-create", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ path: "auth_info" })
  });

  await fetch("/api/actions/start", { method: "POST" });

  return "Sessao desconectada. Aguarde o novo QR Code.";
}

document.querySelectorAll("[data-log]").forEach((button) => {
  button.addEventListener("click", () => {
    state.activeLog = button.dataset.log;
    document.querySelectorAll("[data-log]").forEach((item) => item.classList.remove("active"));
    button.classList.add("active");
    refreshLogs();
  });
});

if (elements.clearLogsButton) {
  elements.clearLogsButton.addEventListener("click", async () => {
    elements.logs.textContent = "Limpando logs...";

    try {
      await fetch("/api/logs/clear", { method: "POST" });
      await refreshLogs();
    } catch (error) {
      elements.logs.textContent = `Falha ao limpar logs: ${error.message}`;
    }
  });
}

async function refreshAll() {
  const tasks = [
    refreshStatus(),
    refreshLogs(),
    maybeRefreshIaConfig(),
    refreshAdmins(),
    refreshDevice(),
    refreshOutbox(),
    refreshInbox()
  ];

  if (!state.groupUpdateInFlight) {
    tasks.push(refreshGroups());
  }

  tasks.push(refreshEvents());

  await Promise.all(tasks);
}

async function refreshStatus() {
  const response = await fetch("/api/status");
  const data = await response.json();
  const processStatus = data.process?.status || "unknown";
  const connection = data.runtime?.connection || "unknown";

  elements.processStatus.textContent = processStatus;
  elements.processStatus.className = `status-pill ${processStatus}`;
  elements.connection.textContent = connection;
  elements.pm2.textContent = processStatus;
  elements.memory.textContent = formatBytes(data.process?.memory || 0);
  elements.cpu.textContent = `${data.process?.cpu || 0}%`;
  elements.deviceConnection.textContent = connection;
  elements.deviceProcess.textContent = processStatus;
  elements.deviceMemory.textContent = formatBytes(data.process?.memory || 0);
  elements.deviceCpu.textContent = `${data.process?.cpu || 0}%`;
  elements.gemini.textContent = data.gemini?.configured ? "configurada" : "sem chave";
  elements.geminiModel.textContent = data.gemini?.model || "-";
  elements.geminiQuota.textContent = formatGeminiQuota(data.gemini?.quota);
  elements.updatedAt.textContent = data.runtime?.updatedAt
    ? `Atualizado em ${new Date(data.runtime.updatedAt).toLocaleString()}`
    : "Sem atualizacao ainda.";

  if (data.qrImage) {
    elements.qrState.textContent = "Aguardando leitura";
    elements.qrBox.innerHTML = `<img src="${data.qrImage}" alt="QR Code do WhatsApp">`;
  } else {
    elements.qrState.textContent = connection === "open" ? "Conectado" : "Indisponivel";
    elements.qrBox.innerHTML = "<span>Sem QR ativo</span>";
  }
}

function formatGeminiQuota(quota) {
  if (!quota) return "-";

  const requests = Number(quota.requests || 0);
  const success = Number(quota.success || 0);
  const errors = Number(quota.errors || 0);
  const blocked = Boolean(quota.isBlocked);
  const exhausted = Boolean(quota.isExhausted) || blocked;

  if (exhausted) {
    return "estourada (0 restante)";
  }

  return `${requests} req (${success}/${errors})`;
}

async function refreshDevice() {
  try {
    const response = await fetch("/api/device");
    const data = await response.json();
    renderDevice(data);
  } catch (error) {
    elements.deviceDetails.innerHTML = `<p class="muted">Falha ao carregar hardware: ${escapeHtml(error.message)}</p>`;
  }
}

async function refreshLogs() {
  const response = await fetch("/api/logs?lines=160");
  const data = await response.json();
  elements.logs.textContent = data[state.activeLog] || "Sem logs.";
}

async function refreshGroups() {
  if (state.groupUpdateInFlight) return;

  try {
    const response = await fetch("/api/groups");
    const data = await response.json();
    renderGroups(data.groups || []);
  } catch (error) {
    elements.groupsList.innerHTML = `<p class="muted">Falha ao carregar grupos: ${escapeHtml(error.message)}</p>`;
  }
}

function renderGroups(groups) {
  renderChatGroups(groups);

  if (!groups.length) {
    elements.groupsList.innerHTML = [
      "<p class=\"muted\">Nenhum grupo encontrado ainda.</p>",
      "<p class=\"muted\">Conecte o WhatsApp e envie qualquer mensagem em um grupo onde o bot participa.</p>"
    ].join("");
    return;
  }

  elements.groupsList.innerHTML = groups.map((group) => `
    <article class="group-card" data-jid="${escapeHtml(group.jid)}">
      <div class="group-info">
        <strong>${escapeHtml(group.name || group.jid)}</strong>
        <span>${escapeHtml(group.jid)}</span>
        <small>${Number(group.participants || 0)} participantes</small>
      </div>
      <div class="feature-toggles">
        ${renderToggle(group, "bot", "Bot")}
        ${renderToggle(group, "ia", "IA")}
        ${renderToggle(group, "zoeira", "Zoeira")}
        ${renderToggle(group, "boss", "Boss")}
        ${renderToggle(group, "oly", "Oly")}
        ${renderToggle(group, "alerts", "Alertas")}
      </div>
    </article>
  `).join("");

  elements.groupsList.querySelectorAll("input[data-feature]").forEach((input) => {
    input.addEventListener("change", () => updateGroupFeature(input));
  });
}

async function refreshEvents() {
  if (!elements.eventsGroupSelect || !elements.eventsList) return;

  try {
    const response = await fetch("/api/groups");
    const { data, error } = await readApiJson(response);
    if (error) throw new Error(error);
    renderEventGroupOptions(data.groups || []);
  } catch (error) {
    elements.eventsStatus.textContent = `Falha ao carregar grupos: ${error.message}`;
  }
}

function renderEventGroupOptions(groups) {
  if (!elements.eventsGroupSelect) return;

  const current = elements.eventsGroupSelect.value;
  if (!groups.length) {
    elements.eventsGroupSelect.innerHTML = "<option value=\"\">Nenhum grupo encontrado</option>";
    if (elements.eventsList) {
      elements.eventsList.innerHTML = "<p class=\"muted\">Nenhum grupo para configurar eventos.</p>";
    }
    return;
  }

  elements.eventsGroupSelect.innerHTML = [
    "<option value=\"\">Selecione o grupo do evento</option>",
    ...groups.map((group) => `<option value="${escapeHtml(group.jid)}">${escapeHtml(group.name || group.jid)}</option>`)
  ].join("");

  const selected = groups.some((group) => group.jid === current)
    ? current
    : groups[0].jid;
  elements.eventsGroupSelect.value = selected;
  loadEventReminders(selected);
}

async function createEventReminder() {
  const jid = String(elements.eventsGroupSelect?.value || "").trim();
  const eventAt = String(elements.eventsEventAt?.value || "").trim();
  const notifyBeforeMinutes = Number(elements.eventsNotifyBefore?.value || 0);
  const text = String(elements.eventsText?.value || "").trim();
  const imageUrl = String(elements.eventsImage?.value || "").trim();
  const imageDataUrl = String(state.eventsImageDataUrl || "").trim();
  const repeatMinutes = Number(elements.eventsRepeat?.value || 0);

  if (!jid) {
    elements.eventsStatus.textContent = "Selecione o grupo do evento.";
    return;
  }

  if (!eventAt) {
    elements.eventsStatus.textContent = "Defina data/hora do evento.";
    return;
  }

  if (!Number.isFinite(notifyBeforeMinutes) || notifyBeforeMinutes < 0) {
    elements.eventsStatus.textContent = "Avisar antes deve ser um numero >= 0.";
    return;
  }

  const remindAt = buildReminderAt(eventAt, notifyBeforeMinutes);
  if (!remindAt) {
    elements.eventsStatus.textContent = "Data/hora do evento invalida.";
    return;
  }

  if (!text && !imageUrl && !imageDataUrl) {
    elements.eventsStatus.textContent = "Digite texto ou anexe/imforme imagem.";
    return;
  }

  elements.eventsStatus.textContent = "Salvando evento...";

  try {
    const response = await fetch(`/api/groups/${encodeURIComponent(jid)}/reminders`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        remindAt,
        eventAt,
        notifyBeforeMinutes,
        text,
        imageUrl,
        imageDataUrl,
        repeatMinutes
      })
    });
    const { data, error } = await readApiJson(response);
    if (error) throw new Error(error);

    if (!response.ok || !data.ok) {
      throw new Error(data.error || "Nao foi possivel salvar o evento.");
    }

    elements.eventsText.value = "";
    elements.eventsImage.value = "";
    if (elements.eventsImageFile) elements.eventsImageFile.value = "";
    state.eventsImageDataUrl = "";
    if (elements.eventsNotifyBefore) elements.eventsNotifyBefore.value = "";
    elements.eventsRepeat.value = "";

    const reminderId = data.reminder?.id;
    const groupJid = jid;

    if (reminderId) {
      elements.eventsStatus.innerHTML =
        "Evento salvo. Enviar agora? " +
        `<button id="sendNowBtn" style="margin-left:6px">Sim, enviar agora</button>` +
        `<button id="sendLaterBtn" style="margin-left:4px">Não, aguardar prazo</button>`;

      document.getElementById("sendNowBtn").addEventListener("click", async () => {
        elements.eventsStatus.textContent = "Enviando...";
        try {
          const r = await fetch(`/api/groups/${encodeURIComponent(groupJid)}/reminders/${encodeURIComponent(reminderId)}/send-now`, { method: "POST" });
          const { error } = await readApiJson(r);
          if (error) throw new Error(error);
          elements.eventsStatus.textContent = "Enviando em instantes (até 15s)...";
        } catch (err) {
          elements.eventsStatus.textContent = "Falha ao enviar: " + err.message;
        }
        await loadEventReminders(groupJid);
      });

      document.getElementById("sendLaterBtn").addEventListener("click", () => {
        elements.eventsStatus.textContent = "Evento agendado para o prazo escolhido.";
      });
    } else {
      elements.eventsStatus.textContent = "Evento salvo.";
    }

    await loadEventReminders(jid);
  } catch (error) {
    elements.eventsStatus.textContent = error.message;
  }
}

async function loadEventReminders(jid) {
  if (!elements.eventsList) return;

  if (!jid) {
    elements.eventsList.innerHTML = "<p class=\"muted\">Selecione um grupo para ver os eventos.</p>";
    return;
  }

  try {
    const response = await fetch(`/api/groups/${encodeURIComponent(jid)}/reminders`);
    const { data, error } = await readApiJson(response);
    if (error) throw new Error(error);
    const reminders = data.reminders || [];

    if (!reminders.length) {
      elements.eventsList.innerHTML = "<p class=\"muted\">Nenhum evento neste grupo.</p>";
      return;
    }

    elements.eventsList.innerHTML = reminders.map((item) => {
      const when = formatReminderDate(item.remindAt);
      const eventAt = item.eventAt ? ` | evento ${formatReminderDate(item.eventAt)}` : "";
      const notify = Number(item.notifyBeforeMinutes || 0) > 0
        ? ` | aviso ${item.notifyBeforeMinutes} min antes`
        : "";
      const repeat = Number(item.repeatMinutes || 0) > 0 ? ` | repete ${item.repeatMinutes} min` : "";
      const media = item.imageUrl || item.hasAttachedImage ? " | com imagem" : "";
      const text = escapeHtml(item.text || "[somente imagem]");
      return `
        <article class="reminder-item" data-reminder-id="${escapeHtml(item.id)}">
          <div>
            <strong>Disparo: ${when}</strong>
            <small>${escapeHtml(item.status || "queued")}${eventAt}${notify}${repeat}${media}</small>
            <p>${text}</p>
          </div>
          <button class="small-button danger-button" data-event-delete="${escapeHtml(item.id)}">Remover</button>
        </article>
      `;
    }).join("");

    elements.eventsList.querySelectorAll("[data-event-delete]").forEach((button) => {
      button.addEventListener("click", () => deleteEventReminder(jid, button.dataset.eventDelete));
    });
  } catch (error) {
    elements.eventsList.innerHTML = `<p class=\"muted\">Falha ao carregar eventos: ${escapeHtml(error.message)}</p>`;
  }
}

async function handleEventsImageFileChange() {
  const file = elements.eventsImageFile?.files?.[0];
  if (!file) {
    state.eventsImageDataUrl = "";
    return;
  }

  if (!String(file.type || "").startsWith("image/")) {
    elements.eventsStatus.textContent = "Anexe apenas arquivo de imagem.";
    elements.eventsImageFile.value = "";
    state.eventsImageDataUrl = "";
    return;
  }

  if (file.size > 4 * 1024 * 1024) {
    elements.eventsStatus.textContent = "Imagem muito grande (max 4MB).";
    elements.eventsImageFile.value = "";
    state.eventsImageDataUrl = "";
    return;
  }

  try {
    state.eventsImageDataUrl = await fileToDataUrl(file);
    elements.eventsStatus.textContent = `Imagem anexada: ${file.name}`;
  } catch (error) {
    elements.eventsStatus.textContent = "Falha ao anexar imagem.";
    state.eventsImageDataUrl = "";
  }
}

function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(new Error("Falha ao ler arquivo"));
    reader.readAsDataURL(file);
  });
}

async function deleteEventReminder(jid, id) {
  try {
    const response = await fetch(`/api/groups/${encodeURIComponent(jid)}/reminders/${encodeURIComponent(id)}`, {
      method: "DELETE"
    });
    const { data, error } = await readApiJson(response);
    if (error) throw new Error(error);

    if (!response.ok || !data.ok) {
      throw new Error(data.error || "Nao foi possivel remover evento.");
    }

    elements.eventsStatus.textContent = "Evento removido.";
    await loadEventReminders(jid);
  } catch (error) {
    elements.eventsStatus.textContent = error.message;
  }
}

function formatReminderDate(value) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "Data invalida";
  return date.toLocaleString();
}

function buildReminderAt(eventAt, notifyBeforeMinutes) {
  const eventDate = new Date(eventAt);
  if (Number.isNaN(eventDate.getTime())) return "";
  const remindMs = eventDate.getTime() - Math.floor(notifyBeforeMinutes) * 60 * 1000;
  return new Date(remindMs).toISOString();
}

async function readApiJson(response) {
  const raw = await response.text();

  try {
    return { data: JSON.parse(raw), error: "" };
  } catch (error) {
    const sample = String(raw || "").slice(0, 120).replace(/\s+/g, " ").trim();
    return {
      data: {},
      error: sample
        ? `Resposta invalida do servidor: ${sample}`
        : "Resposta invalida do servidor."
    };
  }
}

function renderChatGroups(groups) {
  const current = elements.chatGroupSelect.value;

  if (!groups.length) {
    elements.chatGroupSelect.innerHTML = "<option value=\"\">Nenhum grupo encontrado</option>";
    return;
  }

  elements.chatGroupSelect.innerHTML = [
    "<option value=\"\">Selecione um grupo</option>",
    ...groups.map((group) => `<option value="${escapeHtml(group.jid)}">${escapeHtml(group.name || group.jid)}</option>`)
  ].join("");

  if (groups.some((group) => group.jid === current)) {
    elements.chatGroupSelect.value = current;
    refreshInbox();
  }
}

async function refreshIaConfig() {
  if (state.iaConfigDirty) return;

  try {
    const response = await fetch("/api/ia-config");
    const data = await response.json();
    renderIaConfig(data.personalities || [], data.config || {});
    state.iaConfigLoaded = true;
  } catch (error) {
    elements.personalityGrid.innerHTML = `<p class="muted">Falha ao carregar IA: ${escapeHtml(error.message)}</p>`;
  }
}

async function maybeRefreshIaConfig() {
  if (state.activeView !== "ia-config" && state.iaConfigLoaded) return;
  await refreshIaConfig();
}

function renderIaConfig(personalities, config) {
  const selected = new Set(config.selected || []);
  const scheduleProfile = config.scheduleProfile || {};
  elements.iaCustomPrompt.value = config.customPrompt || "";
  if (elements.iaScheduleEnabled) elements.iaScheduleEnabled.checked = Boolean(scheduleProfile.enabled);
  if (elements.iaScheduleStart) elements.iaScheduleStart.value = scheduleProfile.start || "08:00";
  if (elements.iaScheduleEnd) elements.iaScheduleEnd.value = scheduleProfile.end || "18:00";
  if (elements.iaScheduleSelected) elements.iaScheduleSelected.value = (scheduleProfile.selected || []).join(",");
  if (elements.iaSchedulePrompt) elements.iaSchedulePrompt.value = scheduleProfile.customPrompt || "";
  if (elements.iaGroupProfiles) elements.iaGroupProfiles.value = formatIaProfiles(config.groupProfiles || []);
  if (elements.iaAdminProfiles) elements.iaAdminProfiles.value = formatIaProfiles(config.adminProfiles || []);

  if (!personalities.length) {
    elements.personalityGrid.innerHTML = "<p class=\"muted\">Nenhuma personalidade disponivel.</p>";
    updateIaActiveLabel();
    return;
  }

  elements.personalityGrid.innerHTML = personalities.map((item) => `
    <label class="personality-card">
      <input type="checkbox" value="${escapeHtml(item.id)}" ${selected.has(item.id) ? "checked" : ""}>
      <span>
        <strong>${escapeHtml(item.name)}</strong>
        <small>${escapeHtml(item.description)}</small>
      </span>
    </label>
  `).join("");

  elements.personalityGrid.querySelectorAll("input[type='checkbox']").forEach((input) => {
    input.addEventListener("change", () => {
      state.iaConfigDirty = true;
      updateIaActiveLabel();
      elements.iaConfigStatus.textContent = "Alteracoes pendentes. Clique em Salvar IA.";
    });
  });
  elements.iaCustomPrompt.oninput = () => {
    state.iaConfigDirty = true;
    elements.iaConfigStatus.textContent = "Alteracoes pendentes. Clique em Salvar IA.";
  };
  [
    elements.iaScheduleEnabled,
    elements.iaScheduleStart,
    elements.iaScheduleEnd,
    elements.iaScheduleSelected,
    elements.iaSchedulePrompt,
    elements.iaGroupProfiles,
    elements.iaAdminProfiles
  ].filter(Boolean).forEach((field) => {
    const handler = () => {
      state.iaConfigDirty = true;
      elements.iaConfigStatus.textContent = "Alteracoes pendentes. Clique em Salvar IA.";
    };

    if (field.type === "checkbox") {
      field.onchange = handler;
    } else {
      field.oninput = handler;
    }
  });
  updateIaActiveLabel();
}

function getSelectedPersonalities() {
  return [...elements.personalityGrid.querySelectorAll("input[type='checkbox']:checked")]
    .map((input) => input.value);
}

function updateIaActiveLabel() {
  const labels = [...elements.personalityGrid.querySelectorAll("input[type='checkbox']:checked")]
    .map((input) => input.closest(".personality-card")?.querySelector("strong")?.textContent || input.value);

  elements.iaActiveLabel.textContent = labels.length ? labels.join(" + ") : "Nenhuma";
}

async function saveIaConfig() {
  elements.saveIaConfigButton.disabled = true;
  elements.iaConfigStatus.textContent = "Salvando configuracao da IA...";

  try {
    const response = await fetch("/api/ia-config", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        selected: getSelectedPersonalities(),
        customPrompt: elements.iaCustomPrompt.value,
        scheduleProfile: {
          enabled: Boolean(elements.iaScheduleEnabled?.checked),
          start: String(elements.iaScheduleStart?.value || "").trim(),
          end: String(elements.iaScheduleEnd?.value || "").trim(),
          selected: parsePersonalityIds(elements.iaScheduleSelected?.value || ""),
          customPrompt: String(elements.iaSchedulePrompt?.value || "").trim()
        },
        groupProfiles: parseIaProfiles(elements.iaGroupProfiles?.value || ""),
        adminProfiles: parseIaProfiles(elements.iaAdminProfiles?.value || "")
      })
    });
    const data = await response.json();

    if (!response.ok || !data.ok) {
      throw new Error(data.error || "Nao foi possivel salvar IA.");
    }

    state.iaConfigDirty = false;
    state.iaConfigLoaded = false;
    elements.iaConfigStatus.textContent = "Config IA salva.";
    await refreshIaConfig();
  } catch (error) {
    elements.iaConfigStatus.textContent = error.message;
  } finally {
    elements.saveIaConfigButton.disabled = false;
  }
}

function parsePersonalityIds(value) {
  return String(value || "")
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean);
}

function parseIaProfiles(value) {
  return String(value || "")
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => {
      const parts = line.split("|").map((item) => item.trim());
      return {
        id: parts[0] || "",
        selected: parsePersonalityIds(parts[1] || ""),
        customPrompt: parts[2] || ""
      };
    })
    .filter((item) => item.id && item.selected.length);
}

function formatIaProfiles(items) {
  return (items || [])
    .map((item) => {
      const ids = Array.isArray(item.selected) ? item.selected.join(",") : "";
      return `${item.id || ""} | ${ids} | ${item.customPrompt || ""}`.trim();
    })
    .join("\n");
}

async function refreshAdmins() {
  try {
    const response = await fetch("/api/admins");
    const data = await response.json();
    renderAdmins(data.admins || []);
  } catch (error) {
    elements.adminsList.innerHTML = `<p class="muted">Falha ao carregar admins: ${escapeHtml(error.message)}</p>`;
  }
}

function renderAdmins(admins) {
  if (!admins.length) {
    elements.adminsList.innerHTML = "<p class=\"muted\">Nenhum admin cadastrado ainda.</p>";
    return;
  }

  elements.adminsList.innerHTML = admins.map((admin) => `
    <article class="admin-card" data-admin-jid="${escapeHtml(admin.jid)}">
      <div>
        <strong>${escapeHtml(admin.name || admin.phone || admin.jid)}</strong>
        <span>${escapeHtml(admin.phone || "-")}</span>
        <small>${escapeHtml(admin.jid)}</small>
      </div>
      <button class="small-button danger-button" data-remove-admin="${escapeHtml(admin.jid)}">Remover</button>
    </article>
  `).join("");

  elements.adminsList.querySelectorAll("[data-remove-admin]").forEach((button) => {
    button.addEventListener("click", () => removeAdmin(button.dataset.removeAdmin));
  });
}

async function addAdminFromForm(event) {
  event.preventDefault();

  const name = elements.adminName.value.trim();
  const phone = elements.adminPhone.value.trim();

  if (!phone) {
    elements.adminStatus.textContent = "Informe o telefone ou JID do admin.";
    return;
  }

  elements.adminStatus.textContent = "Salvando admin...";

  try {
    const response = await fetch("/api/admins", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ name, phone })
    });
    const data = await response.json();

    if (!response.ok || !data.ok) {
      throw new Error(data.error || "Nao foi possivel salvar admin.");
    }

    elements.adminName.value = "";
    elements.adminPhone.value = "";
    elements.adminStatus.textContent = `Admin salvo: ${data.admin.name}`;
    await refreshAdmins();
  } catch (error) {
    elements.adminStatus.textContent = error.message;
  }
}

async function removeAdmin(jid) {
  elements.adminStatus.textContent = "Removendo admin...";

  try {
    const response = await fetch(`/api/admins/${encodeURIComponent(jid)}`, {
      method: "DELETE"
    });
    const data = await response.json();

    if (!response.ok || !data.ok) {
      throw new Error(data.error || "Nao foi possivel remover admin.");
    }

    elements.adminStatus.textContent = data.removed ? "Admin removido." : "Admin nao encontrado.";
    await refreshAdmins();
  } catch (error) {
    elements.adminStatus.textContent = error.message;
  }
}

async function sendChatMessage() {
  const jid = elements.chatGroupSelect.value;
  const text = state.lastCorrectedText || elements.chatMessage.value.trim();

  if (!jid) {
    elements.chatStatus.textContent = "Selecione um grupo.";
    return;
  }

  if (!text) {
    elements.chatStatus.textContent = "Digite uma mensagem.";
    return;
  }

  elements.sendChatButton.disabled = true;
  elements.chatStatus.textContent = "Enfileirando mensagem...";

  try {
    const response = await fetch("/api/send-message", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ jid, text, replyToId: state.replyToId })
    });
    const data = await response.json();

    if (!response.ok || !data.ok) {
      throw new Error(data.error || "Falha ao enviar.");
    }

    elements.chatMessage.value = "";
    clearReplySelection();
    elements.chatStatus.textContent = "Mensagem na fila. O bot vai enviar em negrito.";
    await refreshOutbox();
  } catch (error) {
    elements.chatStatus.textContent = error.message;
  } finally {
    elements.sendChatButton.disabled = false;
  }
}

async function correctChatText() {
  const text = elements.chatMessage.value.trim();

  if (!text) {
    elements.chatStatus.textContent = "Digite uma mensagem para corrigir.";
    return;
  }

  elements.correctChatButton.disabled = true;
  elements.chatStatus.textContent = "Corrigindo portugues...";

  try {
    const response = await fetch("/api/correct-text", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ text })
    });
    const data = await response.json();

    if (!response.ok || !data.ok) {
      throw new Error(data.error || "Falha ao corrigir.");
    }

    elements.chatMessage.value = data.text || text;
    state.lastCorrectedText = data.text || text;
    renderSuggestions(data.suggestions || []);
    elements.chatStatus.textContent = "Texto corrigido. Revise antes de enviar.";
  } catch (error) {
    elements.chatStatus.textContent = error.message;
  } finally {
    elements.correctChatButton.disabled = false;
  }
}

function scheduleCorrectionPreview() {
  state.lastCorrectedText = "";
  clearTimeout(state.correctionTimer);
  state.correctionTimer = setTimeout(refreshCorrectionPreview, 450);
}

function handleChatMessageInput(event) {
  if (state.autoCorrecting) return;

  scheduleCorrectionPreview();

  if (isWordBoundaryInput(event)) {
    clearTimeout(state.autoCorrectionTimer);
    state.autoCorrectionTimer = setTimeout(applyAutomaticCorrection, 90);
  }
}

function isWordBoundaryInput(event) {
  const value = elements.chatMessage.value;
  const cursor = elements.chatMessage.selectionStart;
  const inserted = event.data || value[cursor - 1] || "";

  return cursor === value.length && /[\s,.;:!?)]/.test(inserted);
}

async function applyAutomaticCorrection() {
  const text = elements.chatMessage.value;

  if (!text.trim()) return;

  try {
    const response = await fetch("/api/correct-text", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ text })
    });
    const data = await response.json();

    if (!response.ok || !data.ok) return;

    const corrected = data.text || text;
    state.lastCorrectedText = corrected;
    renderSuggestions(data.suggestions || []);

    if (corrected !== text) {
      state.autoCorrecting = true;
      elements.chatMessage.value = corrected;
      elements.chatMessage.setSelectionRange(corrected.length, corrected.length);
      state.autoCorrecting = false;
      elements.chatStatus.textContent = "Correcao automatica aplicada.";
    }
  } catch (error) {
    renderSuggestions([]);
  }
}

async function refreshCorrectionPreview() {
  const text = elements.chatMessage.value.trim();

  if (!text) {
    state.lastCorrectedText = "";
    renderSuggestions([]);
    return;
  }

  try {
    const response = await fetch("/api/correct-text", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ text })
    });
    const data = await response.json();

    if (!response.ok || !data.ok) return;

    state.lastCorrectedText = data.text || text;
    renderSuggestions(data.suggestions || []);
  } catch (error) {
    renderSuggestions([]);
  }
}

function renderSuggestions(suggestions) {
  if (!suggestions.length) {
    elements.suggestionsPanel.innerHTML = "<span class=\"mini\">Texto sem sugestoes no momento.</span>";
    return;
  }

  elements.suggestionsPanel.innerHTML = [
    "<span class=\"mini\">Sugestoes automaticas:</span>",
    ...suggestions.map((item) => `
      <button class="suggestion-chip" data-word="${escapeHtml(item.word)}" data-suggestion="${escapeHtml(item.suggestion)}">
        ${escapeHtml(item.word)} &rarr; ${escapeHtml(item.suggestion)}
      </button>
    `)
  ].join("");

  elements.suggestionsPanel.querySelectorAll("[data-word]").forEach((button) => {
    button.addEventListener("click", () => applySuggestion(button.dataset.word, button.dataset.suggestion));
  });
}

function applySuggestion(word, suggestion) {
  const escaped = escapeRegExp(word);
  const pattern = new RegExp(`(^|[^\\p{L}])(${escaped})(?=$|[^\\p{L}])`, "giu");

  elements.chatMessage.value = elements.chatMessage.value.replace(pattern, (match, prefix) => {
    return `${prefix}${suggestion}`;
  });
  scheduleCorrectionPreview();
}

async function refreshInbox() {
  const jid = elements.chatGroupSelect.value;

  if (!jid) {
    state.inboxMessages = [];
    elements.inboxList.innerHTML = "<p class=\"muted\">Selecione um grupo para ver as mensagens.</p>";
    return;
  }

  try {
    const response = await fetch(`/api/inbox?jid=${encodeURIComponent(jid)}&limit=50`);
    const data = await response.json();
    state.inboxMessages = data.messages || [];
    renderInbox(state.inboxMessages);
  } catch (error) {
    elements.inboxList.innerHTML = `<p class="muted">Falha ao carregar mensagens: ${escapeHtml(error.message)}</p>`;
  }
}

function renderInbox(messages) {
  if (!messages.length) {
    elements.inboxList.innerHTML = "<p class=\"muted\">Nenhuma mensagem recebida nesse grupo ainda.</p>";
    return;
  }

  elements.inboxList.innerHTML = messages.slice(0, 20).map((item) => `
    <article class="inbox-item ${state.replyToId === item.id ? "selected" : ""}">
      <div>
        <strong>${escapeHtml(item.pushName || item.participant || "Contato")}</strong>
        <small>${escapeHtml(formatInboxTime(item.receivedAt))}</small>
      </div>
      <p>${escapeHtml(item.text)}</p>
      <button class="small-button" data-reply-id="${escapeHtml(item.id)}">Responder</button>
    </article>
  `).join("");

  elements.inboxList.querySelectorAll("[data-reply-id]").forEach((button) => {
    button.addEventListener("click", () => selectReply(button.dataset.replyId));
  });
}

function selectReply(id) {
  const item = state.inboxMessages.find((message) => message.id === id);
  if (!item) return;

  state.replyToId = id;
  elements.replyPreview.classList.remove("hidden");
  elements.replyAuthor.textContent = item.pushName || item.participant || "Contato";
  elements.replyText.textContent = item.text;
  elements.chatStatus.textContent = "Resposta marcada. A proxima mensagem vai citar essa conversa.";
  renderInbox(state.inboxMessages);
}

function clearReplySelection() {
  state.replyToId = null;
  elements.replyPreview.classList.add("hidden");
  elements.replyAuthor.textContent = "-";
  elements.replyText.textContent = "-";
  renderInbox(state.inboxMessages);
}

async function refreshOutbox() {
  try {
    const response = await fetch("/api/outbox");
    const data = await response.json();
    renderOutbox(data.messages || []);
  } catch (error) {
    elements.outboxList.innerHTML = `<p class="muted">Falha ao carregar historico: ${escapeHtml(error.message)}</p>`;
  }
}

function renderOutbox(messages) {
  if (!messages.length) {
    elements.outboxList.innerHTML = "<p class=\"muted\">Sem mensagens recentes.</p>";
    return;
  }

  elements.outboxList.innerHTML = messages.slice(0, 8).map((item) => `
    <article class="outbox-item ${escapeHtml(item.status)}">
      <div>
        <strong>${escapeHtml(item.groupName || item.jid)}</strong>
        <span>${escapeHtml(formatOutboxStatus(item.status))}</span>
      </div>
      <p>${escapeHtml(item.text)}</p>
      ${item.replyToId ? "<small>Enviada como resposta marcada</small>" : ""}
      <small>${escapeHtml(formatOutboxTime(item))}</small>
    </article>
  `).join("");
}

function formatOutboxStatus(status) {
  const labels = {
    queued: "Na fila",
    sent: "Enviada",
    error: "Erro"
  };

  return labels[status] || status || "-";
}

function formatOutboxTime(item) {
  const value = item.sentAt || item.createdAt;
  return value ? new Date(value).toLocaleString() : "-";
}

function formatInboxTime(value) {
  return value ? new Date(value).toLocaleString() : "-";
}

function renderToggle(group, feature, label) {
  const checked = group.features?.[feature] !== false ? "checked" : "";

  return `
    <label class="switch">
      <input type="checkbox" data-feature="${feature}" ${checked}>
      <span>${label}</span>
    </label>
  `;
}

async function updateGroupFeature(input) {
  const card = input.closest("[data-jid]");
  const jid = card.dataset.jid;
  const feature = input.dataset.feature;
  const desiredValue = Boolean(input.checked);

  input.disabled = true;
  state.groupUpdateInFlight = true;

  try {
    const response = await fetch(`/api/groups/${encodeURIComponent(jid)}/features`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        features: {
          [feature]: desiredValue
        }
      })
    });
    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
      throw new Error("Nao foi possivel salvar.");
    }

    if (feature === "zoeira") {
      await ensureZoeiraFeaturePersisted(jid, desiredValue, data.features || {});
    }

    const confirmed = await confirmGroupFeature(jid, feature, desiredValue);
    if (!confirmed) {
      throw new Error("O painel nao confirmou a gravacao. Tente novamente.");
    }

    await refreshGroups();
  } catch (error) {
    input.checked = !desiredValue;
    alert(error.message);
  } finally {
    state.groupUpdateInFlight = false;
    input.disabled = false;
  }
}

async function confirmGroupFeature(jid, feature, expected) {
  for (let i = 0; i < 2; i += 1) {
    const response = await fetch("/api/groups");
    if (!response.ok) continue;

    const data = await response.json().catch(() => ({}));
    const group = (data.groups || []).find((item) => item.jid === jid);
    if (!group) continue;

    const actual = group.features?.[feature] !== false;
    if (actual === expected) {
      return true;
    }
  }

  return false;
}

async function ensureZoeiraFeaturePersisted(jid, enabled, apiFeatures) {
  if (Object.prototype.hasOwnProperty.call(apiFeatures || {}, "zoeira") && Boolean(apiFeatures.zoeira) === Boolean(enabled)) {
    return;
  }

  const path = "data/group-settings.json";
  const readResponse = await fetch(`/api/code-file?path=${encodeURIComponent(path)}`);
  let settings = {};

  if (readResponse.ok) {
    const readData = await readResponse.json();
    try {
      settings = JSON.parse(readData.content || "{}");
    } catch (error) {
      settings = {};
    }
  }

  if (!settings || typeof settings !== "object" || Array.isArray(settings)) {
    settings = {};
  }

  const current = settings[jid] && typeof settings[jid] === "object" ? settings[jid] : {};
  settings[jid] = {
    ...current,
    zoeira: Boolean(enabled),
    updatedAt: new Date().toISOString()
  };

  const writeResponse = await fetch("/api/code-file", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      path,
      content: JSON.stringify(settings, null, 2)
    })
  });

  if (!writeResponse.ok) {
    throw new Error("Nao foi possivel persistir a opcao de zoeira.");
  }
}

function formatBytes(bytes) {
  if (!bytes) return "0 MB";
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

function renderDevice(data) {
  elements.deviceCollectedAt.textContent = data.collectedAt
    ? new Date(data.collectedAt).toLocaleTimeString()
    : "-";

  const cpuTemp = formatTemperature(data.thermal?.cpuCurrentC);
  const batteryTemp = formatTemperature(data.thermal?.batteryC);
  const cpuUsage = estimateCpuUsage(data.cpu);
  const memoryUsage = normalizePercent(data.memory?.usagePercent);
  const mainStorage = getMainStorage(data.storage || []);
  const storageUsage = normalizePercent(mainStorage?.usagePercent);
  const cpuTempPercent = temperatureToPercent(data.thermal?.cpuCurrentC);
  const batteryTempPercent = temperatureToPercent(data.thermal?.batteryC);
  const networkRows = (data.network?.interfaces || [])
    .filter((item) => item.addresses?.some((address) => !address.internal))
    .map((item) => {
      const ips = item.addresses
        .filter((address) => !address.internal)
        .map((address) => address.address)
        .join(", ");
      const rxRate = item.rates ? formatRate(item.rates.rxBytesPerSecond) : "Indisponivel";
      const txRate = item.rates ? formatRate(item.rates.txBytesPerSecond) : "Indisponivel";

      return `${item.name}: ${ips || "-"} | RX ${rxRate} | TX ${txRate}`;
    });

  elements.deviceDetails.innerHTML = [
    renderMetricCard("Indicadores principais", [
      { label: "Processador", value: `${cpuUsage}%`, percent: cpuUsage, type: "usage" },
      { label: "Memoria", value: `${memoryUsage}%`, percent: memoryUsage, type: "usage" },
      { label: "Armazenamento", value: `${storageUsage}%`, percent: storageUsage, type: "usage" },
      { label: "Temp. CPU", value: cpuTemp, percent: cpuTempPercent, type: "temperature" },
      { label: "Temp. bateria", value: batteryTemp, percent: batteryTempPercent, type: "temperature" }
    ]),
    renderInfoCard("Sistema", [
      ["Modelo", data.system?.model],
      ["Fabricante", data.system?.manufacturer],
      ["Android", data.system?.android],
      ["SDK", data.system?.sdk],
      ["Kernel", data.system?.kernel],
      ["Arquitetura", data.system?.abi || data.system?.arch],
      ["Uptime", formatDuration(data.system?.uptimeSeconds)]
    ]),
    renderInfoCard("Processador", [
      ["Chipset", data.cpu?.model || data.system?.soc],
      ["Plataforma", data.system?.board],
      ["Nucleos", data.cpu?.cores],
      ["Freq. media", formatMhz(data.cpu?.averageFrequencyMhz)],
      ["Temp. CPU", cpuTemp],
      ["Load", formatLoad(data.cpu?.loadAverage)]
    ]),
    renderInfoCard("Memoria", [
      ["Total", formatBytes(data.memory?.total)],
      ["Usada", `${formatBytes(data.memory?.used)} (${data.memory?.usagePercent ?? "-"}%)`],
      ["Disponivel", formatBytes(data.memory?.available)],
      ["Cache", formatBytes(data.memory?.cached)],
      ["Swap usada", formatBytes(data.memory?.swapUsed)]
    ]),
    renderInfoCard("Bateria", [
      ["Carga", formatPercent(data.battery?.percent)],
      ["Status", data.battery?.status],
      ["Saude", data.battery?.health],
      ["Tecnologia", data.battery?.technology],
      ["Temperatura", batteryTemp],
      ["Voltagem", formatNumber(data.battery?.voltageV, " V")],
      ["Corrente", formatNumber(data.battery?.currentMa, " mA")]
    ]),
    renderInfoCard("Armazenamento", (data.storage || []).map((disk) => [
      disk.mount,
      `${formatBytes(disk.used)} / ${formatBytes(disk.total)} (${disk.usagePercent}%)`
    ])),
    renderInfoCard("Rede", [
      ["IP principal", data.network?.primaryIp],
      ["Taxas", data.network?.ratesAvailable ? "Ativas" : "Indisponiveis no Android"],
      ...networkRows.map((row) => ["Interface", row])
    ]),
    renderInfoCard("Temperaturas", [
      ["Bateria", batteryTemp],
      ["CPU max", cpuTemp],
      ["CPU media", formatTemperature(data.thermal?.cpuAverageC)],
      ["GPU", formatTemperature(data.thermal?.gpuC)],
      ["Memoria", formatTemperature(data.thermal?.memoryC)]
    ]),
    renderInfoCard("Frequencias por nucleo", (data.cpu?.frequencies || []).map((item) => [
      `CPU ${item.core}`,
      `${formatMhz(item.currentMhz)} / max ${formatMhz(item.maxMhz)}`
    ]))
  ].join("");
}

function renderInfoCard(title, rows) {
  return `
    <section class="info-card">
      <h3>${escapeHtml(title)}</h3>
      <dl>
        ${rows.map(([label, value]) => `
          <div>
            <dt>${escapeHtml(label)}</dt>
            <dd>${escapeHtml(value ?? "Indisponivel")}</dd>
          </div>
        `).join("")}
      </dl>
    </section>
  `;
}

function renderMetricCard(title, metrics) {
  return `
    <section class="info-card metric-card">
      <h3>${escapeHtml(title)}</h3>
      <div class="metric-list">
        ${metrics.map((metric) => renderMetric(metric)).join("")}
      </div>
    </section>
  `;
}

function renderMetric(metric) {
  const percent = normalizePercent(metric.percent);
  const type = metric.type === "temperature" ? "temperature" : "usage";

  return `
    <div class="metric-row">
      <div class="metric-label">
        <span>${escapeHtml(metric.label)}</span>
        <strong>${escapeHtml(metric.value ?? "Indisponivel")}</strong>
      </div>
      <div class="meter ${type}" aria-label="${escapeHtml(metric.label)} ${percent}%">
        <span style="width: ${percent}%"></span>
      </div>
      <div class="meter-scale">
        <span>0</span>
        <span>100</span>
      </div>
    </div>
  `;
}

function estimateCpuUsage(cpu) {
  const cores = Number(cpu?.cores || 1);
  const load = Number(cpu?.loadAverage?.[0] || 0);
  return normalizePercent(Math.round((load / cores) * 100));
}

function getMainStorage(storage) {
  return storage.find((disk) => disk.mount === "/data") ||
    storage.find((disk) => disk.mount === "/storage/emulated") ||
    storage[0] ||
    null;
}

function normalizePercent(value) {
  const number = Number(value);

  if (!Number.isFinite(number)) return 0;
  return Math.max(0, Math.min(100, Math.round(number)));
}

function temperatureToPercent(value) {
  const number = Number(value);

  if (!Number.isFinite(number)) return 0;

  return normalizePercent(((number - 20) / 60) * 100);
}

function formatPercent(value) {
  return Number.isFinite(value) ? `${value}%` : "Indisponivel";
}

function formatMhz(value) {
  return Number.isFinite(value) ? `${Math.round(value)} MHz` : "Indisponivel";
}

function formatTemperature(value) {
  return Number.isFinite(value) ? `${value.toFixed(1)} °C` : "Indisponivel";
}

function formatNumber(value, suffix) {
  return Number.isFinite(value) ? `${value.toFixed(2)}${suffix}` : "Indisponivel";
}

function formatLoad(values) {
  return Array.isArray(values) ? values.map((value) => value.toFixed(2)).join(" / ") : "Indisponivel";
}

function formatRate(bytesPerSecond) {
  return `${formatBytes(bytesPerSecond)}/s`;
}

function formatDuration(seconds) {
  if (!Number.isFinite(seconds)) return "Indisponivel";

  const days = Math.floor(seconds / 86400);
  const hours = Math.floor((seconds % 86400) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);

  return `${days}d ${hours}h ${minutes}m`;
}

function showView(view) {
  state.activeView = view;
  document.querySelectorAll("[data-view]").forEach((section) => {
    section.classList.toggle("active", section.dataset.view === view);
  });

  if (view === "ia-config" && !state.iaConfigDirty) {
    refreshIaConfig();
  }

  if (view === "events") {
    refreshEvents();
  }
}

function escapeHtml(value) {
  return String(value || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function escapeRegExp(value) {
  return String(value || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

async function copyText(text) {
  if (navigator.clipboard?.writeText) {
    await navigator.clipboard.writeText(text);
    return;
  }

  const input = document.createElement("textarea");
  input.value = text;
  input.setAttribute("readonly", "");
  input.style.position = "fixed";
  input.style.opacity = "0";
  document.body.appendChild(input);
  input.select();
  document.execCommand("copy");
  document.body.removeChild(input);
}

refreshAll();
setInterval(refreshAll, 5000);
