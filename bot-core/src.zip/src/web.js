"use strict";

const childProcess = require("child_process");
const fs = require("fs");
const os = require("os");
const path = require("path");

const express = require("express");
const QRCode = require("qrcode");

const { initLogger } = require("./lib/logger");

const { addAdmin, getAdmins, removeAdmin } = require("./lib/admins");
const { readStatus, writeStatus } = require("./lib/runtime-status");
const { isGeminiConfigured, GEMINI_MODEL, getGeminiQuotaStatus } = require("./lib/gemini");
const { subscribeBossAlerts, unsubscribeBossAlerts } = require("./lib/boss-alerts");
const { getDeviceInfo } = require("./lib/device-info");
const { getGroupsWithSettings, setGroupFeatures } = require("./lib/group-settings");
const { getIaConfig, saveIaConfig } = require("./lib/ia-personality");
const { getInbox } = require("./lib/inbound-messages");
const { enqueueOutboundMessage, getOutboundHistory } = require("./lib/outbound-messages");
const { createGroupReminder, listGroupReminders, removeGroupReminder, sendReminderNow } = require("./lib/group-reminders");
const { correctPortugueseText, getCorrectionSuggestions } = require("./lib/text-correction");

const app = express();
const PORT = Number(process.env.WEB_PORT || 3000);
const HOST = process.env.WEB_HOST || "0.0.0.0";
const BOT_PM2_NAME = process.env.BOT_PM2_NAME || "novo-bot";
const PM2_HOME = process.env.PM2_HOME || path.join(os.homedir(), ".pm2");
const BOT_ROOT = path.resolve(__dirname, "..");
const LOCAL_LOG_DIR = process.env.DATA_DIR
  ? path.resolve(process.cwd(), process.env.DATA_DIR)
  : path.resolve(BOT_ROOT, "data");
const LOCAL_BOT_ENTRY = path.join(BOT_ROOT, "src", "index.js");
const LOCAL_BOT_PID_FILE = path.join(LOCAL_LOG_DIR, "bot.pid");
const AUTH_DIR_NAME = process.env.AUTH_DIR || "auth_info";
const AUTH_DIR_PATH = path.resolve(BOT_ROOT, AUTH_DIR_NAME);
const IGNORED_DIRS = new Set(["node_modules", ".git", "auth_info"]);
let pm2AvailableCache = null;

initLogger("web");

app.use(express.json({ limit: "25mb" }));
app.use(express.static(path.join(__dirname, "web")));

app.use((error, req, res, next) => {
  if (!error) {
    next();
    return;
  }

  if (error.type === "entity.too.large") {
    res.status(413).json({ ok: false, error: "Arquivo muito grande. Reduza a imagem e tente novamente." });
    return;
  }

  if (error instanceof SyntaxError && "body" in error) {
    res.status(400).json({ ok: false, error: "JSON invalido na requisicao." });
    return;
  }

  next(error);
});

app.get("/api/code-files", (req, res) => {
  try {
    const files = listBotFiles(BOT_ROOT);
    res.json({ ok: true, files });
  } catch (error) {
    res.status(500).json({ ok: false, error: `Erro ao listar arquivos: ${error.message}` });
  }
});

app.get("/api/code-file", (req, res) => {
  const relPath = String(req.query.path || "");
  if (!relPath) {
    res.status(400).json({ ok: false, error: "path requerido" });
    return;
  }

  try {
    const absPath = resolveBotPath(relPath);
    if (!fs.existsSync(absPath)) {
      res.status(404).json({ ok: false, error: "Arquivo nao encontrado" });
      return;
    }
    if (fs.statSync(absPath).isDirectory()) {
      res.status(400).json({ ok: false, error: "Path informado e uma pasta" });
      return;
    }
    const content = fs.readFileSync(absPath, "utf8");
    res.json({ ok: true, content });
  } catch (error) {
    res.status(400).json({ ok: false, error: "Path invalido" });
  }
});

app.post("/api/code-file", (req, res) => {
  const relPath = String(req.body?.path || "");
  const content = String(req.body?.content || "");
  if (!relPath) {
    res.status(400).json({ ok: false, error: "path requerido" });
    return;
  }

  try {
    const absPath = resolveBotPath(relPath);
    fs.mkdirSync(path.dirname(absPath), { recursive: true });
    fs.writeFileSync(absPath, content, "utf8");
    clearAllLogs();
    res.json({ ok: true });
  } catch (error) {
    res.status(400).json({ ok: false, error: "Path invalido" });
  }
});

app.post("/api/code-file-create", (req, res) => {
  const relPath = String(req.body?.path || "");
  const content = String(req.body?.content || "");
  if (!relPath) {
    res.status(400).json({ ok: false, error: "path requerido" });
    return;
  }

  try {
    const absPath = resolveBotPath(relPath);
    if (fs.existsSync(absPath)) {
      res.status(400).json({ ok: false, error: "Arquivo ja existe" });
      return;
    }
    fs.mkdirSync(path.dirname(absPath), { recursive: true });
    fs.writeFileSync(absPath, content, "utf8");
    clearAllLogs();
    res.json({ ok: true });
  } catch (error) {
    res.status(400).json({ ok: false, error: "Path invalido" });
  }
});

app.post("/api/code-folder-create", (req, res) => {
  const relPath = String(req.body?.path || "");
  if (!relPath) {
    res.status(400).json({ ok: false, error: "path requerido" });
    return;
  }

  try {
    const absPath = resolveBotPath(relPath);
    if (fs.existsSync(absPath)) {
      res.status(400).json({ ok: false, error: "Pasta ja existe" });
      return;
    }
    fs.mkdirSync(absPath, { recursive: true });
    clearAllLogs();
    res.json({ ok: true });
  } catch (error) {
    res.status(400).json({ ok: false, error: "Path invalido" });
  }
});

app.post("/api/code-rename", (req, res) => {
  const oldPath = String(req.body?.oldPath || "");
  const newPath = String(req.body?.newPath || "");
  if (!oldPath || !newPath) {
    res.status(400).json({ ok: false, error: "oldPath e newPath requeridos" });
    return;
  }

  try {
    const absOld = resolveBotPath(oldPath);
    const absNew = resolveBotPath(newPath);
    if (!fs.existsSync(absOld)) {
      res.status(404).json({ ok: false, error: "Origem nao encontrada" });
      return;
    }
    fs.mkdirSync(path.dirname(absNew), { recursive: true });
    fs.renameSync(absOld, absNew);
    clearAllLogs();
    res.json({ ok: true });
  } catch (error) {
    res.status(400).json({ ok: false, error: "Path invalido" });
  }
});

app.post("/api/code-delete", (req, res) => {
  const relPath = String(req.body?.path || "");
  if (!relPath) {
    res.status(400).json({ ok: false, error: "path requerido" });
    return;
  }

  try {
    const absPath = resolveBotPath(relPath);
    if (!fs.existsSync(absPath)) {
      res.status(404).json({ ok: false, error: "Arquivo ou pasta nao encontrado" });
      return;
    }
    const stat = fs.statSync(absPath);
    if (stat.isDirectory()) {
      fs.rmSync(absPath, { recursive: true, force: true });
    } else {
      fs.unlinkSync(absPath);
    }
    clearAllLogs();
    res.json({ ok: true });
  } catch (error) {
    res.status(400).json({ ok: false, error: "Path invalido" });
  }
});

app.get("/api/status", async (req, res) => {
  const runtime = readStatus();
  const processInfo = await getProcessInfo(BOT_PM2_NAME);
  const qrImage = runtime.qr ? await QRCode.toDataURL(runtime.qr, { margin: 1, width: 320 }) : null;

  res.json({
    runtime,
    process: processInfo,
    qrImage,
    server: {
      name: "novo-bot-web",
      port: PORT,
      now: new Date().toISOString()
    },
    gemini: {
      configured: isGeminiConfigured(),
      model: GEMINI_MODEL,
      quota: getGeminiQuotaStatus()
    }
  });
});

app.get("/api/logs", async (req, res) => {
  const lines = Math.min(Number(req.query.lines || 120), 400);
  const outLog = mergeLogFiles([
    path.join(PM2_HOME, "logs", `${BOT_PM2_NAME}-out.log`),
    path.join(LOCAL_LOG_DIR, "bot.log"),
    path.join(LOCAL_LOG_DIR, "web.log")
  ], lines);
  const errorLog = mergeLogFiles([
    path.join(PM2_HOME, "logs", `${BOT_PM2_NAME}-error.log`),
    path.join(LOCAL_LOG_DIR, "bot-error.log"),
    path.join(LOCAL_LOG_DIR, "web-error.log")
  ], lines);

  res.json({
    out: outLog || "",
    error: errorLog || ""
  });
});

app.post("/api/logs/clear", (req, res) => {
  const files = clearAllLogs();
  res.json({ ok: true, cleared: files });
});

app.get("/api/groups", (req, res) => {
  res.json({
    groups: getGroupsWithSettings()
  });
});

app.get("/api/admins", (req, res) => {
  res.json({
    admins: getAdmins()
  });
});

app.post("/api/admins", (req, res) => {
  try {
    const admin = addAdmin({
      phone: req.body?.phone,
      jid: req.body?.jid,
      name: req.body?.name
    });

    res.json({
      ok: true,
      admin
    });
  } catch (error) {
    res.status(400).json({
      ok: false,
      error: error.message
    });
  }
});

app.delete("/api/admins/:jid", (req, res) => {
  const removed = removeAdmin(decodeURIComponent(req.params.jid));

  res.json({
    ok: true,
    removed
  });
});

app.get("/api/device", (req, res) => {
  res.json(getDeviceInfo());
});

app.get("/api/ia-config", (req, res) => {
  res.json(getIaConfig());
});

app.post("/api/ia-config", (req, res) => {
  res.json({
    ok: true,
    config: saveIaConfig(req.body || {})
  });
});

app.get("/api/outbox", (req, res) => {
  res.json({
    messages: getOutboundHistory()
  });
});

app.get("/api/inbox", (req, res) => {
  res.json({
    messages: getInbox({
      jid: req.query.jid,
      limit: req.query.limit
    })
  });
});

app.post("/api/correct-text", (req, res) => {
  const text = String(req.body?.text || "");

  res.json({
    ok: true,
    text: correctPortugueseText(text),
    suggestions: getCorrectionSuggestions(text)
  });
});

app.post("/api/send-message", (req, res) => {
  const jid = req.body?.jid;
  const text = req.body?.text;
  const replyToId = req.body?.replyToId;
  const group = getGroupsWithSettings().find((item) => item.jid === jid);

  if (!group) {
    res.status(400).json({ ok: false, error: "Grupo nao encontrado." });
    return;
  }

  try {
    const queued = enqueueOutboundMessage({
      jid,
      groupName: group.name,
      text: correctPortugueseText(text),
      replyToId
    });

    res.json({
      ok: true,
      queued
    });
  } catch (error) {
    res.status(400).json({
      ok: false,
      error: error.message
    });
  }
});

app.post("/api/groups/:jid/features", (req, res) => {
  const jid = decodeURIComponent(req.params.jid);
  const features = req.body?.features || {};
  const saved = setGroupFeatures(jid, features);

  if (features.alerts === true) {
    subscribeBossAlerts(jid);
  }

  if (features.alerts === false) {
    unsubscribeBossAlerts(jid);
  }

  res.json({
    ok: true,
    jid,
    features: saved
  });
});

app.get("/api/groups/:jid/reminders", (req, res) => {
  const jid = decodeURIComponent(req.params.jid);

  res.json({
    ok: true,
    jid,
    reminders: listGroupReminders(jid)
  });
});

app.post("/api/groups/:jid/reminders", (req, res) => {
  const jid = decodeURIComponent(req.params.jid);
  const group = getGroupsWithSettings().find((item) => item.jid === jid);

  if (!group) {
    res.status(400).json({ ok: false, error: "Grupo nao encontrado." });
    return;
  }

  try {
    const reminder = createGroupReminder({
      jid,
      groupName: group.name,
      text: req.body?.text,
      imageUrl: req.body?.imageUrl,
      imageDataUrl: req.body?.imageDataUrl,
      eventAt: req.body?.eventAt,
      notifyBeforeMinutes: req.body?.notifyBeforeMinutes,
      remindAt: req.body?.remindAt,
      repeatMinutes: req.body?.repeatMinutes
    });

    res.json({ ok: true, reminder });
  } catch (error) {
    res.status(400).json({ ok: false, error: error.message });
  }
});

app.delete("/api/groups/:jid/reminders/:id", (req, res) => {
  const jid = decodeURIComponent(req.params.jid);
  const id = String(req.params.id || "");

  res.json({
    ok: true,
    removed: removeGroupReminder(jid, id)
  });
});

app.post("/api/groups/:jid/reminders/:id/send-now", (req, res) => {
  const id = String(req.params.id || "");

  try {
    sendReminderNow(id);
    res.json({ ok: true });
  } catch (error) {
    res.status(400).json({ ok: false, error: error.message });
  }
});

app.post("/api/actions/:action", async (req, res) => {
  const action = req.params.action;
  const allowed = new Set(["start", "restart", "stop", "save", "disconnect"]);

  if (!allowed.has(action)) {
    res.status(400).json({ error: "Acao invalida." });
    return;
  }

  try {
    const output = await runAction(action);
    res.json({ ok: true, output });
  } catch (error) {
    res.status(500).json({ ok: false, error: error.message, output: error.output });
  }
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "web", "index.html"));
});

app.listen(PORT, HOST, () => {
  console.log(`Gerenciador web em http://${HOST}:${PORT}`);
});

async function getProcessInfo(name) {
  if (await hasPm2()) {
    try {
      const output = await runPm2(["jlist"]);
      const list = JSON.parse(output);
      const processInfo = list.find((item) => item.name === name);

      if (!processInfo) {
        return getLocalProcessInfo(name);
      }

      return {
        name: processInfo.name,
        status: processInfo.pm2_env?.status || "unknown",
        restarts: processInfo.pm2_env?.restart_time || 0,
        uptime: processInfo.pm2_env?.pm_uptime || null,
        pid: processInfo.pid || null,
        memory: processInfo.monit?.memory || 0,
        cpu: processInfo.monit?.cpu || 0
      };
    } catch (error) {
      return {
        ...(getLocalProcessInfo(name)),
        status: "pm2-error",
        error: error.message
      };
    }
  }

  return getLocalProcessInfo(name);
}

async function getStartCommand(name) {
  const processInfo = await getProcessInfo(name);

  if (processInfo.status && processInfo.status !== "missing" && processInfo.status !== "pm2-error") {
    return ["start", name];
  }

  return ["start", "src/index.js", "--name", name];
}

async function runAction(action) {
  if (action === "disconnect") {
    return disconnectAndRegenerateQr();
  }

  if (await hasPm2()) {
    const actions = {
      restart: ["restart", BOT_PM2_NAME],
      stop: ["stop", BOT_PM2_NAME],
      save: ["save"]
    };
    const command = action === "start"
      ? await getStartCommand(BOT_PM2_NAME)
      : actions[action];

    if (!command) {
      throw new Error("Acao invalida.");
    }

    return runPm2(command);
  }

  if (action === "save") {
    return "PM2 indisponivel no host local.";
  }

  if (action === "start") {
    const pid = startLocalBot();
    return `Bot iniciado em modo local (pid ${pid}).`;
  }

  if (action === "stop") {
    const stopped = stopLocalBot();
    return stopped ? "Bot local parado." : "Bot local ja estava parado.";
  }

  if (action === "restart") {
    stopLocalBot();
    const pid = startLocalBot();
    return `Bot reiniciado em modo local (pid ${pid}).`;
  }

  throw new Error("Acao invalida.");
}

async function disconnectAndRegenerateQr() {
  writeStatus({
    connection: "disconnecting",
    qr: null,
    lastError: null
  });

  if (await hasPm2()) {
    await runPm2Safe(["stop", BOT_PM2_NAME]);
    resetAuthSession();
    const startCommand = await getStartCommand(BOT_PM2_NAME);
    await runPm2(startCommand);

    return "Sessao desconectada. Aguardando novo QR Code.";
  }

  stopLocalBot();
  resetAuthSession();
  startLocalBot();

  return "Sessao desconectada. Aguardando novo QR Code.";
}

function resetAuthSession() {
  try {
    if (fs.existsSync(AUTH_DIR_PATH)) {
      fs.rmSync(AUTH_DIR_PATH, { recursive: true, force: true });
    }
    fs.mkdirSync(AUTH_DIR_PATH, { recursive: true });
  } catch (error) {
    throw new Error(`Falha ao limpar sessao: ${error.message}`);
  }
}

async function hasPm2() {
  if (pm2AvailableCache !== null) return pm2AvailableCache;

  try {
    await runPm2(["-v"]);
    pm2AvailableCache = true;
  } catch (error) {
    pm2AvailableCache = false;
  }

  return pm2AvailableCache;
}

function getLocalProcessInfo(name) {
  const pid = readLocalBotPid();
  const online = Boolean(pid && isPidRunning(pid));

  return {
    name,
    status: online ? "online" : "missing",
    restarts: 0,
    uptime: null,
    pid: online ? pid : null,
    memory: 0,
    cpu: 0,
    manager: "local"
  };
}

function startLocalBot() {
  const currentPid = readLocalBotPid();
  if (currentPid && isPidRunning(currentPid)) return currentPid;

  fs.mkdirSync(LOCAL_LOG_DIR, { recursive: true });

  const child = childProcess.spawn(process.execPath, [LOCAL_BOT_ENTRY], {
    cwd: BOT_ROOT,
    detached: true,
    stdio: "ignore",
    windowsHide: true
  });

  child.unref();
  fs.writeFileSync(LOCAL_BOT_PID_FILE, String(child.pid), "utf8");
  return child.pid;
}

function stopLocalBot() {
  const pid = readLocalBotPid();
  if (!pid || !isPidRunning(pid)) {
    safeUnlink(LOCAL_BOT_PID_FILE);
    return false;
  }

  try {
    process.kill(pid);
  } catch (error) {
    if (process.platform === "win32") {
      childProcess.spawn("taskkill", ["/PID", String(pid), "/F"], {
        windowsHide: true,
        stdio: "ignore"
      });
    }
  }

  safeUnlink(LOCAL_BOT_PID_FILE);
  return true;
}

function readLocalBotPid() {
  try {
    const value = fs.readFileSync(LOCAL_BOT_PID_FILE, "utf8").trim();
    const pid = Number(value);
    return Number.isFinite(pid) ? pid : 0;
  } catch (error) {
    return 0;
  }
}

function isPidRunning(pid) {
  try {
    process.kill(pid, 0);
    return true;
  } catch (error) {
    return false;
  }
}

function safeUnlink(filePath) {
  try {
    fs.unlinkSync(filePath);
  } catch (error) {
    // ignore
  }
}

function runPm2(args) {
  return new Promise((resolve, reject) => {
    childProcess.execFile("pm2", args, { cwd: process.cwd() }, (error, stdout, stderr) => {
      const output = `${stdout || ""}${stderr || ""}`.trim();

      if (error) {
        error.output = output;
        reject(error);
        return;
      }

      resolve(output);
    });
  });
}

function runPm2Safe(args) {
  return runPm2(args).catch(() => "");
}

function resolveBotPath(relativePath) {
  const safePath = String(relativePath || "").replace(/\\/g, "/").trim();
  if (!safePath || safePath.startsWith("/") || safePath.includes("../") || safePath.includes("..\\")) {
    throw new Error("invalid-path");
  }
  const fullPath = path.normalize(path.join(BOT_ROOT, safePath));
  return fullPath;
}

function listBotFiles(rootDir) {
  const output = [];

  function walk(currentDir) {
    let entries = [];
    try {
      entries = fs.readdirSync(currentDir, { withFileTypes: true });
    } catch (error) {
      return;
    }

    for (const entry of entries) {
      const fullPath = path.join(currentDir, entry.name);
      const relPath = path.relative(rootDir, fullPath).replace(/\\/g, "/");

      // Avoid traversing symlinks to prevent loops/out-of-root issues.
      let stat = null;
      try {
        stat = fs.lstatSync(fullPath);
      } catch (error) {
        continue;
      }

      if (stat.isSymbolicLink()) {
        continue;
      }

      if (entry.isDirectory() || stat.isDirectory()) {
        if (IGNORED_DIRS.has(entry.name)) continue;
        walk(fullPath);
        continue;
      }

      if (entry.isFile() || stat.isFile()) {
        output.push(relPath);
      }
    }
  }

  walk(rootDir);
  return output.sort((a, b) => a.localeCompare(b, "pt-BR"));
}

function tailFile(filePath, lines) {
  if (!filePath) return "";

  try {
    const content = fs.readFileSync(filePath, "utf8");
    return content.split(/\r?\n/).slice(-lines).join("\n").trim();
  } catch (error) {
    return "";
  }
}

function mergeLogFiles(filePaths, lines) {
  const chunks = [];

  for (const filePath of filePaths) {
    if (!filePath || !fs.existsSync(filePath)) continue;

    const content = tailFile(filePath, lines);
    if (!content) continue;

    const name = path.basename(filePath);
    chunks.push(`[${name}]\n${content}`);
  }

  if (!chunks.length) return "";

  return chunks.join("\n\n");
}

function clearAllLogs() {
  const files = [
    path.join(PM2_HOME, "logs", `${BOT_PM2_NAME}-out.log`),
    path.join(PM2_HOME, "logs", `${BOT_PM2_NAME}-error.log`),
    path.join(LOCAL_LOG_DIR, "bot.log"),
    path.join(LOCAL_LOG_DIR, "bot-error.log"),
    path.join(LOCAL_LOG_DIR, "web.log"),
    path.join(LOCAL_LOG_DIR, "web-error.log")
  ];
  const cleared = [];

  for (const filePath of files) {
    try {
      if (!fs.existsSync(filePath)) continue;
      fs.truncateSync(filePath, 0);
      cleared.push(filePath);
    } catch (error) {
      continue;
    }
  }

  return cleared;
}

function pickExistingLogFile(paths) {
  for (const filePath of paths) {
    try {
      if (fs.existsSync(filePath) && fs.statSync(filePath).size > 0) {
        return filePath;
      }
    } catch (error) {
      continue;
    }
  }

  return "";
}
