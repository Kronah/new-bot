"use strict";

const { getMessageText, reply } = require("../lib/messages");
const { formatOlyRanking, getOlyRanking } = require("../lib/oly-ranking");

async function handleOly(sock, msg) {
  const text = getMessageText(msg).trim();
  const filter = parseFilter(text);

  await sendPresence(sock, msg, "composing");

  try {
    const data = await getOlyRanking();
    await reply(sock, msg, formatOlyRanking(data, filter));
  } catch (error) {
    console.error("Erro Oly Ranking:", error.message);
    await reply(sock, msg, `Nao consegui buscar o ranking da olympiad agora.\n${error.message}`);
  } finally {
    await sendPresence(sock, msg, "paused");
  }
}

function isOlyCommand(text) {
  return /^!oly(?:\s|$)/i.test(String(text || "").trim());
}

function parseFilter(text) {
  return String(text || "")
    .replace(/^!oly(?:\s+)?/i, "")
    .trim();
}

async function sendPresence(sock, msg, presence) {
  try {
    await sock.sendPresenceUpdate(presence, msg.key.remoteJid);
  } catch (error) {
    console.error(`Falha ao atualizar presenca (${presence}):`, error.message);
  }
}

module.exports = {
  handleOly,
  isOlyCommand
};
