"use strict";

const { getMessageText, reply } = require("../lib/messages");

async function handleVendas(sock, msg) {
  const text = getMessageText(msg).trim().toLowerCase();

  if (text === "1" || text.includes("venda")) {
    await reply(sock, msg, [
      "Voce entrou no setor de Vendas.",
      "",
      "Me diga qual produto ou servico voce quer comprar.",
      "Digite 0 para voltar ao menu."
    ].join("\n"));
    return;
  }

  await reply(sock, msg, [
    "Recebi sua mensagem para Vendas.",
    "Um atendente pode continuar daqui, ou voce pode automatizar respostas neste arquivo.",
    "",
    "Digite 0 para voltar ao menu."
  ].join("\n"));
}

module.exports = {
  handleVendas
};
