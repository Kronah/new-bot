"use strict";

const { getMessageText, reply } = require("../lib/messages");

async function handleSuporte(sock, msg) {
  const text = getMessageText(msg).trim().toLowerCase();

  if (text === "2" || text.includes("suporte")) {
    await reply(sock, msg, [
      "Voce entrou no setor de Suporte.",
      "",
      "Descreva o problema com o maximo de detalhes.",
      "Digite 0 para voltar ao menu."
    ].join("\n"));
    return;
  }

  await reply(sock, msg, [
    "Recebi sua mensagem para Suporte.",
    "Voce pode personalizar as verificacoes e respostas neste arquivo.",
    "",
    "Digite 0 para voltar ao menu."
  ].join("\n"));
}

module.exports = {
  handleSuporte
};
