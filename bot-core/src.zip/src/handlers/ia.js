"use strict";

const { askGemini, isGeminiConfigured, GEMINI_MODEL } = require("../lib/gemini");
const { adaptAnswerToPersonality, buildIaSystemPrompt, getIaPersonalityLabel } = require("../lib/ia-personality");
const { getMessageText, reply } = require("../lib/messages");
const { searchWebAnswer } = require("../lib/web-search");
const { getZoeiraReply } = require("../lib/zoeira");
const {
  getOfflineAnswer,
  learnFromOnlineAnswer,
  learnPair,
  parseLearningCommand,
  rememberInteraction
} = require("../lib/offline-ai");

async function handleIa(sock, msg, options = {}) {
  const preferOnline = Boolean(options.preferOnline);
  const context = {
    jid: msg.key.remoteJid,
    senderJid: options.senderJid,
    isAdmin: options.isAdmin
  };
  const text = getMessageText(msg).trim();
  const isBotPrefix = /^\s*[!./]?bot\b/i.test(text);
  const cleanText = text.replace(/^\s*[!./]?(ia|ai|bot|gemini)\s*[:,;-]?\s*/i, "").trim();
  const learning = parseLearningCommand(cleanText || text);

  if (learning) {
    learnPair(learning.question, learning.answer, "manual");
    await reply(sock, msg, [
      "Aprendido.",
      "",
      `Pergunta: ${learning.question}`,
      `Resposta: ${learning.answer}`
    ].join("\n"));
    return;
  }

  const mustUseZoeira = isBotPrefix || !preferOnline;

  if (mustUseZoeira) {
    const zoeiraReply = getZoeiraReply(cleanText || text);
    if (zoeiraReply) {
      rememberInteraction(cleanText || text, zoeiraReply, "zoeira-file");
      await reply(sock, msg, zoeiraReply);
      return;
    }

    await reply(sock, msg, "To sem munição no zoeira.json pra essa. Me adiciona mais frase la.");
    return;
  }

  if (!isGeminiConfigured()) {
    const offline = getOfflineAnswer(cleanText);
    const formatted = adaptAnswerToPersonality(offline.answer, context);
    rememberInteraction(cleanText, formatted, offline.source);
    await reply(sock, msg, formatted);
    return;
  }

  if (!cleanText) {
    await reply(sock, msg, [
      "Voce entrou no atendimento com IA.",
      "",
      `Modelo atual: ${GEMINI_MODEL}`,
      `Personalidade: ${getIaPersonalityLabel(context)}`,
      "Envie sua pergunta ou pedido.",
      "",
      "Para ensinar respostas:",
      "aprenda: pergunta => resposta"
    ].join("\n"));
    return;
  }

  await sendPresence(sock, msg, "composing");

  try {
    const answer = await askGemini(cleanText, {
      systemPrompt: buildIaSystemPrompt(context)
    });
    learnFromOnlineAnswer(cleanText, answer);
    await reply(sock, msg, answer);
  } catch (error) {
    console.error("Erro Gemini:", error.message);

    const webAnswer = await searchWebAnswer(cleanText);

    if (webAnswer) {
      const formatted = adaptAnswerToPersonality(webAnswer, context);
      rememberInteraction(cleanText, formatted, "web-search");
      await reply(sock, msg, formatted);
      return;
    }

    const offline = getOfflineAnswer(cleanText);
    const formatted = adaptAnswerToPersonality(offline.answer, context);
    rememberInteraction(cleanText, formatted, offline.source);
    await reply(sock, msg, formatted);
  } finally {
    await sendPresence(sock, msg, "paused");
  }
}

async function sendPresence(sock, msg, presence) {
  try {
    await sock.sendPresenceUpdate(presence, msg.key.remoteJid);
  } catch (error) {
    console.error(`Falha ao atualizar presenca (${presence}):`, error.message);
  }
}

module.exports = {
  handleIa
};
