"use strict";

const { reply } = require("../lib/messages");

async function handleMenu(sock, msg) {
  await reply(sock, msg, [
    "Assistente IA",
    "",
    "No privado, envie qualquer mensagem que eu respondo com IA hibrida.",
    "Em grupos, comece a mensagem com ia, bot ou gemini.",
    "Se a IA online ficar sem cota, eu continuo no modo offline.",
    "",
    "Bosses Divolion: !boss",
    "Olympiad Ranking: !oly",
    "Filtrar classe: !oly maestro",
    "Exemplo: ia resuma esse texto",
    "Ensinar offline: aprenda: pergunta => resposta"
  ].join("\n"));
}

module.exports = {
  handleMenu
};
