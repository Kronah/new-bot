"use strict";

const fs = require("fs");
const path = require("path");

const DICTIONARY_FILE = process.env.PORTUGUESE_DICTIONARY_FILE ||
  path.join(__dirname, "..", "data", "portuguese-words.json");

let cached = null;

function getPortugueseDictionary() {
  if (cached) return cached;

  const words = readWords();
  const wordSet = new Set(words);
  const buckets = new Map();

  for (const word of words) {
    const key = getBucketKey(word);
    const bucket = buckets.get(key) || [];
    bucket.push(word);
    buckets.set(key, bucket);
  }

  cached = {
    words,
    wordSet,
    buckets
  };

  return cached;
}

function hasWord(word) {
  return getPortugueseDictionary().wordSet.has(String(word || "").toLowerCase());
}

function suggestWord(word) {
  const cleanWord = String(word || "").toLowerCase();
  if (cleanWord.length < 4 || hasWord(cleanWord)) return null;

  const candidates = getCandidateWords(cleanWord);
  let best = null;
  let bestDistance = Infinity;

  for (const candidate of candidates) {
    const distance = levenshtein(cleanWord, candidate, bestDistance);
    if (distance < bestDistance) {
      best = candidate;
      bestDistance = distance;
    }
  }

  const maxDistance = cleanWord.length <= 5 ? 1 : 2;
  return bestDistance <= maxDistance ? best : null;
}

function getCandidateWords(word) {
  const dictionary = getPortugueseDictionary();
  const first = normalizeForBucket(word[0] || "");
  const normalizedLength = removeAccents(word).length;
  const candidates = [];

  for (let length = normalizedLength - 2; length <= normalizedLength + 2; length += 1) {
    const bucket = dictionary.buckets.get(`${first}:${length}`);
    if (bucket) candidates.push(...bucket);
  }

  return candidates;
}

function getBucketKey(word) {
  return `${normalizeForBucket(word[0] || "")}:${removeAccents(word).length}`;
}

function normalizeForBucket(value) {
  return removeAccents(value).toLowerCase();
}

function removeAccents(value) {
  return String(value || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}

function levenshtein(a, b, stopAt = Infinity) {
  const left = removeAccents(a);
  const right = removeAccents(b);
  const previous = Array.from({ length: right.length + 1 }, (_, index) => index);
  const current = new Array(right.length + 1);

  for (let i = 1; i <= left.length; i += 1) {
    current[0] = i;
    let rowBest = current[0];

    for (let j = 1; j <= right.length; j += 1) {
      const cost = left[i - 1] === right[j - 1] ? 0 : 1;
      current[j] = Math.min(
        current[j - 1] + 1,
        previous[j] + 1,
        previous[j - 1] + cost
      );
      rowBest = Math.min(rowBest, current[j]);
    }

    if (rowBest > stopAt) return rowBest;

    for (let j = 0; j <= right.length; j += 1) {
      previous[j] = current[j];
    }
  }

  return previous[right.length];
}

function readWords() {
  try {
    const data = JSON.parse(fs.readFileSync(DICTIONARY_FILE, "utf8"));
    return Array.isArray(data) ? data.filter(Boolean) : [];
  } catch (error) {
    return [];
  }
}

module.exports = {
  getPortugueseDictionary,
  hasWord,
  suggestWord
};
