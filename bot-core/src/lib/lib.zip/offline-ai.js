"use strict";

const fs = require("fs");
const path = require("path");

const { loadEnv } = require("./env");

loadEnv();

const DATA_DIR = process.env.DATA_DIR || path.join(process.cwd(), "data");
const MEMORY_FILE = process.env.OFFLINE_AI_MEMORY_FILE || path.join(DATA_DIR, "offline-ai-memory.json");
const MIN_MATCH_SCORE = Number(process.env.OFFLINE_AI_MIN_MATCH_SCORE || 0.28);
const MAX_MEMORY_ITEMS = Number(process.env.OFFLINE_AI_MAX_MEMORY_ITEMS || 500);

const STOP_WORDS = new Set([
  "a", "o", "as", "os", "um", "uma", "uns", "umas", "de", "do", "da", "dos", "das",
  "e", "ou", "que", "com", "sem", "para", "pra", "por", "em", "no", "na", "nos", "nas",
  "me", "te", "se", "eu", "voce", "voces", "ele", "ela", "eles", "elas", "isso", "isto",
  "como", "qual", "quais", "quando", "onde", "porque", "por que"
]);

const DEFAULT_RESPONSES = [
  {
    tags: ["saudacao"],
    patterns: ["oi", "ola", "bom dia", "boa tarde", "boa noite"],
    answer: "Ola! Me diga como posso ajudar."
  },
  {
    tags: ["preco", "valor", "orcamento"],
    patterns: ["preco", "valor", "quanto custa", "orcamento"],
    answer: "Posso te ajudar com valores, comparacoes e contas. Me diga o contexto e o que voce quer calcular."
  },
  {
    tags: ["suporte", "problema", "erro"],
    patterns: ["problema", "erro", "suporte", "nao funciona", "ajuda"],
    answer: "Entendi. Descreva o problema com detalhes e, se puder, envie prints ou mensagens de erro."
  },
  {
    tags: ["atendente", "humano"],
    patterns: ["atendente", "humano", "pessoa", "falar com alguem"],
    answer: "Certo. Vou deixar sua mensagem pronta para um atendente continuar o atendimento."
  }
];

function readMemory() {
  try {
    return normalizeMemory(JSON.parse(fs.readFileSync(MEMORY_FILE, "utf8")));
  } catch (error) {
    return normalizeMemory({});
  }
}

function writeMemory(memory) {
  fs.mkdirSync(path.dirname(MEMORY_FILE), { recursive: true });
  fs.writeFileSync(MEMORY_FILE, JSON.stringify(normalizeMemory(memory), null, 2));
}

function normalizeMemory(memory) {
  return {
    version: 1,
    interactions: Array.isArray(memory.interactions) ? memory.interactions : [],
    learned: Array.isArray(memory.learned) ? memory.learned : []
  };
}

function learnPair(question, answer, source = "manual") {
  const normalizedQuestion = normalizeText(question);
  const normalizedAnswer = String(answer || "").trim();

  if (!normalizedQuestion || !normalizedAnswer) {
    return null;
  }

  const memory = readMemory();
  const existing = memory.learned.find((item) => normalizeText(item.question) === normalizedQuestion);
  const now = new Date().toISOString();

  if (existing) {
    existing.answer = normalizedAnswer;
    existing.source = source;
    existing.updatedAt = now;
    existing.hits = existing.hits || 0;
  } else {
    memory.learned.unshift({
      question: String(question).trim(),
      answer: normalizedAnswer,
      source,
      hits: 0,
      createdAt: now,
      updatedAt: now
    });
  }

  memory.learned = memory.learned.slice(0, MAX_MEMORY_ITEMS);
  writeMemory(memory);

  return existing || memory.learned[0];
}

function rememberInteraction(question, answer, source) {
  const normalizedQuestion = normalizeText(question);
  const normalizedAnswer = String(answer || "").trim();

  if (!normalizedQuestion || !normalizedAnswer) return;

  const memory = readMemory();

  memory.interactions.unshift({
    question: String(question).trim(),
    answer: normalizedAnswer,
    source,
    createdAt: new Date().toISOString()
  });

  memory.interactions = memory.interactions.slice(0, MAX_MEMORY_ITEMS);
  writeMemory(memory);
}

function learnFromOnlineAnswer(question, answer) {
  if (!shouldAutoLearn(question, answer)) return null;

  rememberInteraction(question, answer, "online");
  return learnPair(question, answer, "online");
}

function getOfflineAnswer(question) {
  const cleanQuestion = String(question || "").trim();

  if (!cleanQuestion) {
    return {
      answer: "Me envie sua pergunta ou pedido.",
      confidence: 1,
      source: "offline-empty"
    };
  }

  const mathResult = trySolveMathFromText(cleanQuestion);

  if (mathResult) {
    return {
      answer: mathResult,
      confidence: 1,
      source: "offline-math"
    };
  }

  const learnedMatch = findBestLearnedMatch(cleanQuestion);

  if (learnedMatch && learnedMatch.score >= MIN_MATCH_SCORE) {
    incrementHits(learnedMatch.item);

    return {
      answer: learnedMatch.item.answer,
      confidence: learnedMatch.score,
      source: "offline-learned"
    };
  }

  const defaultMatch = findBestDefaultMatch(cleanQuestion);

  if (defaultMatch) {
    return {
      answer: defaultMatch.answer,
      confidence: defaultMatch.score,
      source: "offline-default"
    };
  }

  const cultural = findCulturalFallback(cleanQuestion);

  if (cultural) {
    return {
      answer: cultural,
      confidence: 0.68,
      source: "offline-cultural"
    };
  }

  return {
    answer: [
      "Ainda nao aprendi uma resposta boa para isso.",
      "Voce pode me ensinar assim:",
      "aprenda: pergunta => resposta"
    ].join("\n"),
    confidence: 0,
    source: "offline-fallback"
  };
}

function findCulturalFallback(question) {
  const normalized = normalizeText(question);

  if (!normalized) return "";

  if (normalized.includes("buraco de paca") || normalized.includes("tatu caminha dentro")) {
    return [
      "Esse ditado e uma brincadeira de duplo sentido usada em zoeira de grupo.",
      "No sentido literal, a frase so diz que o tatu entra no buraco da paca.",
      "No uso popular, normalmente e dito com malicia e tom de resenha."
    ].join(" ");
  }

  if (normalized.includes("ditado") || normalized.includes("proverbio") || normalized.includes("expressao popular")) {
    return "Posso explicar ditados populares e o sentido de cada um. Envie o ditado completo e eu te explico em linguagem simples.";
  }

  return "";
}

function trySolveMathFromText(text) {
  const expression = extractMathExpression(text);
  if (!expression) return null;

  const tokens = tokenizeMath(expression);
  if (!tokens || !tokens.length) return null;

  const rpn = toRpn(tokens);
  if (!rpn) return null;

  const value = evalRpn(rpn);
  if (!Number.isFinite(value)) return null;

  return `Resposta: ${formatMathValue(value)}`;
}

function extractMathExpression(text) {
  let expression = String(text || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/\?/g, " ")
    .replace(/\s+/g, " ")
    .trim();

  if (!expression) return "";

  expression = expression
    .replace(/raiz\s+quadrada\s+de\s*([^\n]+)/g, "sqrt($1)")
    .replace(/raiz\s+de\s*([^\n]+)/g, "sqrt($1)")
    .replace(/quanto\s+e\s*/g, "")
    .replace(/qual\s+e\s+o\s+resultado\s+de\s*/g, "")
    .replace(/resultado\s+de\s*/g, "")
    .replace(/calcule\s*/g, "")
    .replace(/calcular\s*/g, "")
    .replace(/resolva\s*/g, "")
    .replace(/soma\s+de\s*/g, "")
    .replace(/subtracao\s+de\s*/g, "")
    .replace(/multiplicacao\s+de\s*/g, "")
    .replace(/divisao\s+de\s*/g, "");

  expression = expression
    .replace(/(\d+(?:[.,]\d+)?)\s*por\s*cento\s*de\s*(\d+(?:[.,]\d+)?)/g, "(($1/100)*$2)")
    .replace(/(\d+(?:[.,]\d+)?)\s*%\s*de\s*(\d+(?:[.,]\d+)?)/g, "(($1/100)*$2)")
    .replace(/(\d+(?:[.,]\d+)?)\s*%/g, "($1/100)")
    .replace(/elevado\s+a/g, "^")
    .replace(/mais/g, "+")
    .replace(/menos/g, "-")
    .replace(/vezes/g, "*")
    .replace(/multiplicado\s+por/g, "*")
    .replace(/dividido\s+por/g, "/")
    .replace(/sobre/g, "/")
    .replace(/[x×]/g, "*")
    .replace(/[÷]/g, "/")
    .replace(/,/g, ".")
    .replace(/\s+/g, "");

  const letters = expression.replace(/sqrt/g, "");
  if (/[a-z]/.test(letters)) return "";
  if (!/\d/.test(expression)) return "";
  if (!/^[0-9+\-*/^().]+(?:sqrt[0-9+\-*/^().]*)?$/.test(expression) && /[^0-9+\-*/^().a-z]/.test(expression)) {
    return "";
  }

  return expression;
}

function tokenizeMath(expression) {
  const raw = [];
  let i = 0;

  while (i < expression.length) {
    const char = expression[i];

    if (/[0-9.]/.test(char)) {
      let number = char;
      i += 1;
      while (i < expression.length && /[0-9.]/.test(expression[i])) {
        number += expression[i];
        i += 1;
      }
      if ((number.match(/\./g) || []).length > 1) return null;
      raw.push({ type: "number", value: Number(number) });
      continue;
    }

    if (expression.startsWith("sqrt", i)) {
      raw.push({ type: "func", value: "sqrt" });
      i += 4;
      continue;
    }

    if ("+-*/^()".includes(char)) {
      raw.push({ type: "op", value: char });
      i += 1;
      continue;
    }

    return null;
  }

  const tokens = [];

  for (let index = 0; index < raw.length; index += 1) {
    const token = raw[index];
    const prev = tokens[tokens.length - 1];

    if (needsImplicitMultiply(prev, token)) {
      tokens.push({ type: "op", value: "*" });
    }

    tokens.push(token);
  }

  return tokens;
}

function needsImplicitMultiply(prev, current) {
  if (!prev) return false;

  const prevIsValue = prev.type === "number" || (prev.type === "op" && prev.value === ")");
  const currentStartsValue = current.type === "number" || current.type === "func" || (current.type === "op" && current.value === "(");

  return prevIsValue && currentStartsValue;
}

function toRpn(tokens) {
  const output = [];
  const stack = [];

  for (let i = 0; i < tokens.length; i += 1) {
    const token = tokens[i];

    if (token.type === "number") {
      if (!Number.isFinite(token.value)) return null;
      output.push(token);
      continue;
    }

    if (token.type === "func") {
      stack.push(token);
      continue;
    }

    if (token.type === "op" && token.value === "(") {
      stack.push(token);
      continue;
    }

    if (token.type === "op" && token.value === ")") {
      while (stack.length && !(stack[stack.length - 1].type === "op" && stack[stack.length - 1].value === "(")) {
        output.push(stack.pop());
      }
      if (!stack.length) return null;
      stack.pop();
      if (stack.length && stack[stack.length - 1].type === "func") {
        output.push(stack.pop());
      }
      continue;
    }

    if (token.type === "op") {
      const op = normalizeOperator(tokens, i);

      while (stack.length) {
        const top = stack[stack.length - 1];

        if (top.type === "func") {
          output.push(stack.pop());
          continue;
        }

        if (top.type !== "op" || top.value === "(") break;

        const pTop = precedence(top.value);
        const pCurrent = precedence(op.value);

        const shouldPop = isRightAssociative(op.value)
          ? pCurrent < pTop
          : pCurrent <= pTop;

        if (!shouldPop) break;
        output.push(stack.pop());
      }

      stack.push(op);
      continue;
    }
  }

  while (stack.length) {
    const token = stack.pop();
    if (token.type === "op" && (token.value === "(" || token.value === ")")) return null;
    output.push(token);
  }

  return output;
}

function normalizeOperator(tokens, index) {
  const token = tokens[index];
  if (token.value !== "-") return token;

  const prev = tokens[index - 1];
  const isUnary = !prev ||
    prev.type === "func" ||
    (prev.type === "op" && prev.value !== ")");

  return isUnary ? { type: "op", value: "u-" } : token;
}

function precedence(op) {
  if (op === "+" || op === "-") return 1;
  if (op === "*" || op === "/") return 2;
  if (op === "u-") return 3;
  if (op === "^") return 4;
  return 0;
}

function isRightAssociative(op) {
  return op === "^" || op === "u-";
}

function evalRpn(tokens) {
  const stack = [];

  for (const token of tokens) {
    if (token.type === "number") {
      stack.push(token.value);
      continue;
    }

    if (token.type === "func") {
      if (token.value !== "sqrt" || stack.length < 1) return NaN;
      const value = stack.pop();
      if (value < 0) return NaN;
      stack.push(Math.sqrt(value));
      continue;
    }

    if (token.type === "op") {
      if (token.value === "u-") {
        if (stack.length < 1) return NaN;
        stack.push(-stack.pop());
        continue;
      }

      if (stack.length < 2) return NaN;

      const right = stack.pop();
      const left = stack.pop();

      switch (token.value) {
        case "+":
          stack.push(left + right);
          break;
        case "-":
          stack.push(left - right);
          break;
        case "*":
          stack.push(left * right);
          break;
        case "/":
          if (right === 0) return NaN;
          stack.push(left / right);
          break;
        case "^":
          stack.push(Math.pow(left, right));
          break;
        default:
          return NaN;
      }
    }
  }

  return stack.length === 1 ? stack[0] : NaN;
}

function formatMathValue(value) {
  const rounded = Math.round(value * 1000000) / 1000000;
  return Number.isInteger(rounded)
    ? String(rounded)
    : String(rounded).replace(/\.0+$/, "");
}

function parseLearningCommand(text) {
  const normalized = String(text || "")
    .replace(/\u00A0/g, " ")
    .replace(/[“”]/g, '"')
    .replace(/[‘’]/g, "'")
    .trim();

  const match = normalized.match(/^(aprenda|ensine|corrija)\s*:?\s*(.+?)\s*(?:=>|->|=|⇒)\s*(.+)$/i);

  if (!match) return null;

  return {
    question: match[2].trim(),
    answer: match[3].trim()
  };
}

function findBestLearnedMatch(question) {
  const memory = readMemory();
  let best = null;

  for (const item of memory.learned) {
    const score = similarity(question, item.question);

    if (!best || score > best.score) {
      best = { item, score };
    }
  }

  return best;
}

function findBestDefaultMatch(question) {
  const normalizedQuestion = normalizeText(question);
  let best = null;

  for (const item of DEFAULT_RESPONSES) {
    const candidates = [...item.patterns, ...item.tags];
    const score = Math.max(...candidates.map((candidate) => similarity(normalizedQuestion, candidate)));

    if (score >= MIN_MATCH_SCORE && (!best || score > best.score)) {
      best = { ...item, score };
    }
  }

  return best;
}

function incrementHits(item) {
  const memory = readMemory();
  const found = memory.learned.find((entry) => normalizeText(entry.question) === normalizeText(item.question));

  if (!found) return;

  found.hits = (found.hits || 0) + 1;
  found.updatedAt = new Date().toISOString();
  writeMemory(memory);
}

function shouldAutoLearn(question, answer) {
  const cleanQuestion = String(question || "").trim();
  const cleanAnswer = String(answer || "").trim();

  return cleanQuestion.length >= 8 &&
    cleanAnswer.length >= 8 &&
    cleanAnswer.length <= 1500 &&
    !cleanAnswer.toLowerCase().includes("nao consegui responder");
}

function similarity(a, b) {
  const tokensA = tokenize(a);
  const tokensB = tokenize(b);

  if (!tokensA.size || !tokensB.size) return 0;

  let intersection = 0;

  for (const token of tokensA) {
    if (tokensB.has(token)) intersection += 1;
  }

  const union = new Set([...tokensA, ...tokensB]).size;
  return intersection / union;
}

function tokenize(text) {
  const tokens = normalizeText(text)
    .split(" ")
    .filter((token) => token.length > 1 && !STOP_WORDS.has(token));

  return new Set(tokens);
}

function normalizeText(text) {
  return String(text || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}

module.exports = {
  getOfflineAnswer,
  learnFromOnlineAnswer,
  learnPair,
  parseLearningCommand,
  rememberInteraction
};
