"use strict";

const childProcess = require("child_process");
const fs = require("fs");
const os = require("os");
const path = require("path");

let previousNetworkSample = null;

function getDeviceInfo() {
  const now = Date.now();
  const networkCounters = readNetworkCounters();
  const networkRates = calculateNetworkRates(networkCounters, now);

  previousNetworkSample = {
    at: now,
    counters: networkCounters
  };

  return {
    collectedAt: new Date(now).toISOString(),
    system: getSystemInfo(),
    cpu: getCpuInfo(),
    memory: getMemoryInfo(),
    storage: getStorageInfo(),
    battery: getBatteryInfo(),
    thermal: getThermalInfo(),
    network: getNetworkInfo(networkCounters, networkRates)
  };
}

function getSystemInfo() {
  return {
    hostname: os.hostname(),
    platform: os.platform(),
    arch: os.arch(),
    kernel: os.release(),
    uptimeSeconds: os.uptime(),
    model: getProp("ro.product.model"),
    manufacturer: getProp("ro.product.manufacturer"),
    brand: getProp("ro.product.brand"),
    device: getProp("ro.product.device"),
    android: getProp("ro.build.version.release"),
    sdk: getProp("ro.build.version.sdk"),
    hardware: getProp("ro.hardware") || getProp("ro.boot.hardware"),
    board: getProp("ro.board.platform"),
    soc: getProp("ro.soc.model"),
    abi: getProp("ro.product.cpu.abi")
  };
}

function getCpuInfo() {
  const cpuInfo = readFile("/proc/cpuinfo");
  const cpus = os.cpus();
  const hardware = matchValue(cpuInfo, /^Hardware\s*:\s*(.+)$/m);
  const processor = matchValue(cpuInfo, /^Processor\s*:\s*(.+)$/m);
  const features = matchValue(cpuInfo, /^Features\s*:\s*(.+)$/m);
  const frequencies = readCpuFrequencies();

  return {
    model: hardware || processor || getProp("ro.soc.model") || "Indisponivel",
    cores: cpus.length || countCpuinfoProcessors(cpuInfo),
    architecture: os.arch(),
    loadAverage: os.loadavg(),
    features,
    frequencies,
    averageFrequencyMhz: average(frequencies.map((item) => item.currentMhz).filter(Boolean))
  };
}

function getMemoryInfo() {
  const meminfo = parseKeyValueFile("/proc/meminfo");
  const total = Number(meminfo.MemTotal || 0) * 1024 || os.totalmem();
  const free = Number(meminfo.MemFree || 0) * 1024 || os.freemem();
  const available = Number(meminfo.MemAvailable || 0) * 1024 || free;
  const cached = Number(meminfo.Cached || 0) * 1024;
  const swapTotal = Number(meminfo.SwapTotal || 0) * 1024;
  const swapFree = Number(meminfo.SwapFree || 0) * 1024;

  return {
    total,
    free,
    available,
    used: Math.max(total - available, 0),
    cached,
    swapTotal,
    swapFree,
    swapUsed: Math.max(swapTotal - swapFree, 0),
    usagePercent: total ? Math.round(((total - available) / total) * 100) : null
  };
}

function getStorageInfo() {
  const rows = parseDf(exec("df", ["-k"]));
  const wanted = ["/data", "/storage/emulated", "/sdcard", "/"];

  return rows
    .filter((row) => wanted.includes(row.mount) || row.mount.startsWith("/data"))
    .filter((row, index, list) => list.findIndex((item) => item.mount === row.mount) === index)
    .map((row) => ({
      filesystem: row.filesystem,
      mount: row.mount,
      total: row.blocks * 1024,
      used: row.used * 1024,
      available: row.available * 1024,
      usagePercent: row.usePercent
    }));
}

function getBatteryInfo() {
  const base = "/sys/class/power_supply/battery";
  const tempRaw = readNumber(path.join(base, "temp"));
  const voltageRaw = readNumber(path.join(base, "voltage_now"));
  const currentRaw = readNumber(path.join(base, "current_now"));
  const chargeRaw = readNumber(path.join(base, "charge_counter"));

  return {
    percent: readNumber(path.join(base, "capacity")),
    status: readFile(path.join(base, "status")).trim() || null,
    health: readFile(path.join(base, "health")).trim() || null,
    technology: readFile(path.join(base, "technology")).trim() || null,
    present: readFile(path.join(base, "present")).trim() || null,
    temperatureC: tempRaw === null ? null : tempRaw / 10,
    voltageV: voltageRaw === null ? null : voltageRaw / 1000000,
    currentMa: currentRaw === null ? null : currentRaw / 1000,
    chargeMah: chargeRaw === null ? null : chargeRaw / 1000
  };
}

function getThermalInfo() {
  const zones = readThermalZones();
  const cpuZones = zones.filter((zone) => /cpu|apc|processor/i.test(zone.type));
  const battery = getBatteryInfo().temperatureC;

  return {
    batteryC: battery,
    cpuCurrentC: max(cpuZones.map((zone) => zone.temperatureC)),
    cpuAverageC: average(cpuZones.map((zone) => zone.temperatureC).filter((value) => value !== null)),
    gpuC: max(zones.filter((zone) => /gpu/i.test(zone.type)).map((zone) => zone.temperatureC)),
    memoryC: max(zones.filter((zone) => /ddr|mem/i.test(zone.type)).map((zone) => zone.temperatureC)),
    zones
  };
}

function getNetworkInfo(counters, rates) {
  const interfaces = os.networkInterfaces();

  return {
    interfaces: Object.entries(interfaces).map(([name, addresses]) => ({
      name,
      addresses: addresses.map((address) => ({
        address: address.address,
        family: address.family,
        internal: address.internal,
        mac: address.mac,
        cidr: address.cidr
      })),
      counters: counters[name] || null,
      rates: rates[name] || null
    })),
    primaryIp: findPrimaryIp(interfaces),
    countersAvailable: Object.keys(counters).length > 0,
    ratesAvailable: Object.keys(rates).length > 0
  };
}

function readCpuFrequencies() {
  const base = "/sys/devices/system/cpu";
  const cpus = [];

  for (const name of safeReaddir(base)) {
    if (!/^cpu\d+$/.test(name)) continue;

    const cpuPath = path.join(base, name, "cpufreq");
    const current = readNumber(path.join(cpuPath, "scaling_cur_freq"));
    const minFreq = readNumber(path.join(cpuPath, "cpuinfo_min_freq"));
    const maxFreq = readNumber(path.join(cpuPath, "cpuinfo_max_freq"));
    const governor = readFile(path.join(cpuPath, "scaling_governor")).trim() || null;

    cpus.push({
      core: Number(name.replace("cpu", "")),
      currentMhz: current ? Math.round(current / 1000) : null,
      minMhz: minFreq ? Math.round(minFreq / 1000) : null,
      maxMhz: maxFreq ? Math.round(maxFreq / 1000) : null,
      governor
    });
  }

  return cpus.sort((a, b) => a.core - b.core);
}

function readThermalZones() {
  const base = "/sys/class/thermal";

  return safeReaddir(base)
    .filter((name) => name.startsWith("thermal_zone"))
    .map((name) => {
      const zonePath = path.join(base, name);
      const temp = normalizeTemperature(readNumber(path.join(zonePath, "temp")));

      return {
        zone: name,
        type: readFile(path.join(zonePath, "type")).trim() || name,
        temperatureC: temp
      };
    })
    .filter((zone) => zone.temperatureC !== null)
    .sort((a, b) => String(a.type).localeCompare(String(b.type)));
}

function readNetworkCounters() {
  const base = "/sys/class/net";
  const counters = {};

  for (const name of safeReaddir(base)) {
    const rxBytes = readNumber(path.join(base, name, "statistics", "rx_bytes"));
    const txBytes = readNumber(path.join(base, name, "statistics", "tx_bytes"));
    const rxPackets = readNumber(path.join(base, name, "statistics", "rx_packets"));
    const txPackets = readNumber(path.join(base, name, "statistics", "tx_packets"));

    if (rxBytes === null && txBytes === null) continue;

    counters[name] = {
      rxBytes,
      txBytes,
      rxPackets,
      txPackets,
      state: readFile(path.join(base, name, "operstate")).trim() || null
    };
  }

  return counters;
}

function calculateNetworkRates(counters, now) {
  if (!previousNetworkSample) return {};

  const seconds = Math.max((now - previousNetworkSample.at) / 1000, 1);
  const rates = {};

  for (const [name, current] of Object.entries(counters)) {
    const previous = previousNetworkSample.counters[name];

    if (!previous) continue;

    rates[name] = {
      rxBytesPerSecond: Math.max((current.rxBytes - previous.rxBytes) / seconds, 0),
      txBytesPerSecond: Math.max((current.txBytes - previous.txBytes) / seconds, 0),
      rxPacketsPerSecond: Math.max((current.rxPackets - previous.rxPackets) / seconds, 0),
      txPacketsPerSecond: Math.max((current.txPackets - previous.txPackets) / seconds, 0)
    };
  }

  return rates;
}

function parseDf(output) {
  return output.split(/\r?\n/)
    .slice(1)
    .map((line) => line.trim().split(/\s+/))
    .filter((parts) => parts.length >= 6)
    .map((parts) => ({
      filesystem: parts[0],
      blocks: Number(parts[1]),
      used: Number(parts[2]),
      available: Number(parts[3]),
      usePercent: Number(parts[4].replace("%", "")),
      mount: parts.slice(5).join(" ")
    }))
    .filter((row) => Number.isFinite(row.blocks));
}

function parseKeyValueFile(filePath) {
  const values = {};

  for (const line of readFile(filePath).split(/\r?\n/)) {
    const match = line.match(/^([^:]+):\s+(\d+)/);

    if (match) values[match[1]] = match[2];
  }

  return values;
}

function getProp(name) {
  return exec("getprop", [name]).trim();
}

function exec(command, args = []) {
  try {
    return childProcess.execFileSync(command, args, {
      encoding: "utf8",
      stdio: ["ignore", "pipe", "ignore"],
      timeout: 5000
    });
  } catch (error) {
    return "";
  }
}

function readFile(filePath) {
  try {
    return fs.readFileSync(filePath, "utf8");
  } catch (error) {
    return "";
  }
}

function readNumber(filePath) {
  const value = Number(readFile(filePath).trim());
  return Number.isFinite(value) ? value : null;
}

function safeReaddir(dirPath) {
  try {
    return fs.readdirSync(dirPath);
  } catch (error) {
    return [];
  }
}

function normalizeTemperature(value) {
  if (value === null) return null;
  if (Math.abs(value) > 1000) return value / 1000;
  if (Math.abs(value) > 100) return value / 10;
  return value;
}

function matchValue(value, pattern) {
  const match = value.match(pattern);
  return match ? match[1].trim() : null;
}

function countCpuinfoProcessors(cpuInfo) {
  const matches = cpuInfo.match(/^processor\s*:/gm);
  return matches ? matches.length : 0;
}

function findPrimaryIp(interfaces) {
  for (const addresses of Object.values(interfaces)) {
    for (const address of addresses) {
      if (address.family === "IPv4" && !address.internal) {
        return address.address;
      }
    }
  }

  return null;
}

function average(values) {
  const clean = values.filter((value) => Number.isFinite(value));
  if (!clean.length) return null;
  return clean.reduce((sum, value) => sum + value, 0) / clean.length;
}

function max(values) {
  const clean = values.filter((value) => Number.isFinite(value));
  if (!clean.length) return null;
  return Math.max(...clean);
}

module.exports = {
  getDeviceInfo
};
