"use strict";

const fs = require("fs");
const path = require("path");

const { loadEnv } = require("./env");

loadEnv();

const DATA_DIR = process.env.DATA_DIR || path.join(process.cwd(), "data");
const REMINDERS_FILE = process.env.REMINDERS_FILE || path.join(DATA_DIR, "group-reminders.json");
const REMINDER_INTERVAL_MS = Number(process.env.REMINDER_INTERVAL_MS || 15 * 1000);
const MAX_REMINDERS = Number(process.env.MAX_REMINDERS || 800);
const REMINDER_MAX_RETRIES = Number(process.env.REMINDER_MAX_RETRIES || 10);
const REMINDER_RETRY_DELAY_MS = Number(process.env.REMINDER_RETRY_DELAY_MS || 12000);

let interval = null;
let processing = false;
let sockRef = null;

function createGroupReminder({ jid, groupName, text, imageUrl, imageDataUrl, eventAt, notifyBeforeMinutes, remindAt, repeatMinutes }) {
  const cleanJid = String(jid || "").trim();
  const cleanText = String(text || "").trim();
  const cleanImageUrl = String(imageUrl || "").trim();
  const cleanImageDataUrl = String(imageDataUrl || "").trim();
  const cleanEventAt = String(eventAt || "").trim();
  const parsedAt = parseDate(remindAt);
  const parsedEventAt = cleanEventAt ? parseDate(cleanEventAt) : null;
  const notifyLead = Number(notifyBeforeMinutes || 0);
  const repeat = Number(repeatMinutes || 0);

  if (!cleanJid.endsWith("@g.us")) {
    throw new Error("Grupo invalido.");
  }

  if (!cleanText && !cleanImageUrl && !cleanImageDataUrl) {
    throw new Error("Informe texto ou imagem do lembrete.");
  }

  if (!parsedAt) {
    throw new Error("Data/hora do lembrete invalida.");
  }

  if (cleanEventAt && !parsedEventAt) {
    throw new Error("Data/hora do evento invalida.");
  }

  if (notifyLead < 0) {
    throw new Error("Avisar antes nao pode ser negativo.");
  }

  if (cleanImageUrl && !/^https?:\/\//i.test(cleanImageUrl)) {
    throw new Error("A imagem deve ser uma URL http/https.");
  }

  if (cleanImageDataUrl && !isValidImageDataUrl(cleanImageDataUrl)) {
    throw new Error("Imagem anexada invalida.");
  }

  if (repeat < 0) {
    throw new Error("Repeticao nao pode ser negativa.");
  }

  const reminders = readReminders();
  const item = {
    id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
    jid: cleanJid,
    groupName: String(groupName || cleanJid).trim(),
    text: cleanText,
    imageUrl: cleanImageUrl,
    imageDataUrl: cleanImageDataUrl,
    eventAt: parsedEventAt ? parsedEventAt.toISOString() : null,
    notifyBeforeMinutes: Number.isFinite(notifyLead) ? Math.floor(notifyLead) : 0,
    remindAt: parsedAt.toISOString(),
    repeatMinutes: Number.isFinite(repeat) ? Math.floor(repeat) : 0,
    status: "queued",
    sentCount: 0,
    retryCount: 0,
    nextAttemptAt: null,
    lastSentAt: null,
    error: null,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  reminders.unshift(item);
  writeReminders(reminders.slice(0, MAX_REMINDERS));
  return item;
}

function listGroupReminders(jid) {
  const cleanJid = String(jid || "").trim();
  return readReminders()
    .filter((item) => item.jid === cleanJid)
    .sort((a, b) => new Date(a.remindAt) - new Date(b.remindAt))
    .map(toPublicReminder);
}

function removeGroupReminder(jid, id) {
  const cleanJid = String(jid || "").trim();
  const cleanId = String(id || "").trim();
  const reminders = readReminders();
  const next = reminders.filter((item) => !(item.jid === cleanJid && item.id === cleanId));

  if (next.length === reminders.length) return false;

  writeReminders(next);
  return true;
}

function sendReminderNow(id) {
  const reminders = readReminders();
  const reminder = reminders.find((item) => item.id === id);
  if (!reminder) throw new Error("Evento nao encontrado.");

  updateReminder(id, {
    remindAt: new Date(Date.now() - 1000).toISOString(),
    status: "queued",
    error: null,
    updatedAt: new Date().toISOString()
  });
}

function startReminderProcessor(sock) {
  sockRef = sock;
  if (interval) return;

  interval = setInterval(() => {
    processReminders(sock).catch((error) => {
      console.error("Erro ao processar lembretes:", error.message);
    });
  }, REMINDER_INTERVAL_MS);

  setTimeout(() => {
    processReminders(sock).catch((error) => {
      console.error("Erro ao processar lembretes:", error.message);
    });
  }, 2000);
}

async function processReminders(sock) {
  if (processing || !sock?.sendMessage) return;
  processing = true;

  try {
    const reminders = readReminders();
    const now = Date.now();
    const due = reminders
      .filter((item) => {
        const remindAt = new Date(item.remindAt).getTime();
        const retryCount = Number(item.retryCount || 0);
        const nextAt = item.nextAttemptAt ? new Date(item.nextAttemptAt).getTime() : 0;
        const dueBySchedule = remindAt <= now;
        const dueByRetry = !!nextAt && nextAt <= now;
        if (item.status === "queued" && (dueBySchedule || dueByRetry)) return true;
        if (item.status === "error" && retryCount < REMINDER_MAX_RETRIES && dueByRetry) return true;
        return false;
      })
      .sort((a, b) => new Date(a.remindAt) - new Date(b.remindAt))
      .slice(0, 12);

    for (const reminder of due) {
      try {
        const payload = buildReminderMessagePayload(reminder);

        await sock.sendMessage(reminder.jid, payload);

        if ((reminder.repeatMinutes || 0) > 0) {
          const nextAt = new Date(Date.now() + reminder.repeatMinutes * 60 * 1000).toISOString();
          updateReminder(reminder.id, {
            remindAt: nextAt,
            sentCount: Number(reminder.sentCount || 0) + 1,
            retryCount: 0,
            nextAttemptAt: null,
            lastSentAt: new Date().toISOString(),
            status: "queued",
            error: null,
            updatedAt: new Date().toISOString()
          });
        } else {
          updateReminder(reminder.id, {
            sentCount: Number(reminder.sentCount || 0) + 1,
            retryCount: 0,
            nextAttemptAt: null,
            lastSentAt: new Date().toISOString(),
            status: "sent",
            error: null,
            updatedAt: new Date().toISOString()
          });
        }
      } catch (error) {
        const retryCount = Number(reminder.retryCount || 0) + 1;
        if (isTransientConnectionError(error) && retryCount <= REMINDER_MAX_RETRIES) {
          updateReminder(reminder.id, {
            status: "queued",
            retryCount,
            nextAttemptAt: new Date(Date.now() + REMINDER_RETRY_DELAY_MS * Math.min(retryCount, 6)).toISOString(),
            error: error.message,
            updatedAt: new Date().toISOString()
          });
        } else {
          updateReminder(reminder.id, {
            status: "error",
            retryCount,
            nextAttemptAt: null,
            error: error.message,
            updatedAt: new Date().toISOString()
          });
        }
        console.error(`Falha no lembrete ${reminder.id}:`, error.message);
      }
    }
  } finally {
    processing = false;
  }
}

function updateReminder(id, updates) {
  const reminders = readReminders();
  const index = reminders.findIndex((item) => item.id === id);
  if (index === -1) return;

  reminders[index] = {
    ...reminders[index],
    ...updates
  };
  writeReminders(reminders);
}

function readReminders() {
  try {
    const data = JSON.parse(fs.readFileSync(REMINDERS_FILE, "utf8"));
    return Array.isArray(data) ? data : [];
  } catch (error) {
    return [];
  }
}

function writeReminders(reminders) {
  fs.mkdirSync(path.dirname(REMINDERS_FILE), { recursive: true });
  fs.writeFileSync(REMINDERS_FILE, JSON.stringify(reminders, null, 2));
}

function parseDate(value) {
  const input = String(value || "").trim();
  if (!input) return null;

  const normalized = input.includes("T") ? input : input.replace(" ", "T");
  const parsed = new Date(normalized);
  if (Number.isNaN(parsed.getTime())) return null;
  return parsed;
}

function buildReminderMessagePayload(reminder) {
  if (reminder.imageDataUrl) {
    const buffer = imageDataUrlToBuffer(reminder.imageDataUrl);
    if (buffer) {
      return {
        image: buffer,
        caption: reminder.text || undefined
      };
    }
  }

  if (reminder.imageUrl) {
    return {
      image: { url: reminder.imageUrl },
      caption: reminder.text || undefined
    };
  }

  return { text: reminder.text };
}

function imageDataUrlToBuffer(dataUrl) {
  const match = String(dataUrl || "").match(/^data:image\/[a-zA-Z0-9.+-]+;base64,([A-Za-z0-9+/=\r\n]+)$/);
  if (!match) return null;

  try {
    return Buffer.from(match[1], "base64");
  } catch (error) {
    return null;
  }
}

function isValidImageDataUrl(dataUrl) {
  return Boolean(imageDataUrlToBuffer(dataUrl));
}

function isTransientConnectionError(error) {
  const text = String(error?.message || error || "").toLowerCase();
  return text.includes("connection closed")
    || text.includes("not connected")
    || text.includes("timed out")
    || text.includes("connection terminated")
    || text.includes("ecconnreset")
    || text.includes("stream errored");
}

function toPublicReminder(item) {
  const next = { ...item };
  const hasAttachedImage = Boolean(next.imageDataUrl);
  delete next.imageDataUrl;
  next.hasAttachedImage = hasAttachedImage;
  return next;
}

module.exports = {
  createGroupReminder,
  listGroupReminders,
  removeGroupReminder,
  startReminderProcessor,
  sendReminderNow
};
