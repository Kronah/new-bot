"use strict";

const { hasWord, suggestWord } = require("./portuguese-dictionary");

const REPLACEMENTS = new Map([
  ["aho", "acho"],
  ["vc", "voc\u00ea"],
  ["vcs", "voc\u00eas"],
  ["voce", "voc\u00ea"],
  ["voces", "voc\u00eas"],
  ["vao", "v\u00e3o"],
  ["tb", "tamb\u00e9m"],
  ["tbm", "tamb\u00e9m"],
  ["q", "que"],
  ["pq", "porque"],
  ["pqe", "porque"],
  ["nao", "n\u00e3o"],
  ["n", "n\u00e3o"],
  ["ta", "est\u00e1"],
  ["to", "estou"],
  ["pra", "para"],
  ["pro", "para o"],
  ["obg", "obrigado"],
  ["vlw", "valeu"],
  ["blz", "beleza"],
  ["msg", "mensagem"],
  ["mensgem", "mensagem"],
  ["concerteza", "com certeza"],
  ["certesa", "certeza"],
  ["porisso", "por isso"],
  ["derrepente", "de repente"],
  ["apartir", "a partir"],
  ["assun", "assim"],
  ["portugue", "portugu\u00eas"],
  ["portugues", "portugu\u00eas"],
  ["corriir", "corrigir"],
  ["inicar", "iniciar"],
  ["funcao", "fun\u00e7\u00e3o"],
  ["opcao", "op\u00e7\u00e3o"],
  ["informacoes", "informa\u00e7\u00f5es"],
  ["configuracao", "configura\u00e7\u00e3o"],
  ["diretamentte", "diretamente"]
]);

function correctPortugueseText(text) {
  const original = String(text || "");
  if (!original.trim()) return "";

  const trailingWhitespace = original.match(/\s+$/)?.[0] || "";

  const corrected = original.trim()
    .split(/(\s+)/)
    .map((part) => correctToken(part))
    .join("")
    .replace(/\s+([,.!?;:])/g, "$1")
    .replace(/([,.!?;:])(?=\S)/g, "$1 ")
    .replace(/\s{2,}/g, " ")
    .trim();

  return `${capitalizeSentences(applyContextCorrections(corrected))}${trailingWhitespace}`;
}

function getCorrectionSuggestions(text) {
  const suggestions = [];
  const seen = new Set();
  const tokens = String(text || "").match(/[\p{L}\p{N}_-]+/gu) || [];

  for (const token of tokens) {
    if (shouldSkipToken(token)) continue;

    const lowerWord = token.toLowerCase();
    const suggestion = REPLACEMENTS.get(lowerWord) || getDictionaryReplacement(token);

    if (!suggestion || suggestion.toLowerCase() === lowerWord) continue;

    const key = `${lowerWord}:${suggestion.toLowerCase()}`;
    if (seen.has(key)) continue;

    seen.add(key);
    suggestions.push({
      word: token,
      suggestion: matchCase(token, suggestion)
    });
  }

  return suggestions.slice(0, 12);
}

function correctToken(token) {
  if (/^\s+$/.test(token)) return token;
  if (shouldSkipToken(token)) return token;

  const match = token.match(/^([(["']*)([\p{L}\p{N}_-]+)([)\]"'.,!?;:]*)$/u);
  if (!match) return token;

  const [, prefix, word, suffix] = match;
  const lowerWord = word.toLowerCase();
  const replacement = REPLACEMENTS.get(lowerWord) || getDictionaryReplacement(word);

  if (!replacement) return token;
  return `${prefix}${matchCase(word, replacement)}${suffix}`;
}

function getDictionaryReplacement(word) {
  const lowerWord = String(word || "").toLowerCase();

  if (lowerWord.length < 4) return null;
  if (hasWord(lowerWord)) return null;
  if (/^[A-Z\u00c0-\u00ff]/.test(word)) return null;

  return suggestWord(lowerWord);
}

function shouldSkipToken(token) {
  return /^(https?:\/\/|www\.|[@#!/\\])/i.test(token) ||
    /\d/.test(token) ||
    token.includes("@") ||
    token.includes("_") ||
    token.length > 32;
}

function matchCase(source, replacement) {
  if (source.toUpperCase() === source) return replacement.toUpperCase();
  if (source[0] && source[0].toUpperCase() === source[0]) {
    return `${replacement[0].toUpperCase()}${replacement.slice(1)}`;
  }
  return replacement;
}

function applyContextCorrections(text) {
  return String(text || "")
    .replace(/\b(voc[e\u00ea])\s+e\s+(?=(chato|chata|legal|bom|boa|ruim|lindo|linda|feio|feia|forte|fraco|fraca|inteligente|burro|burra|admin|adm|boss|amigo|amiga|doido|doida|louco|louca)\b)/giu, "você é ")
    .replace(/\b(voc[e\u00ea])\s+eh\s+/giu, "você é ")
    .replace(/\btu\s+e\s+(?!(eu|voc[e\u00ea]|ele|ela|n[o\u00f3]s|a gente|eles|elas)(?=\s|$))/giu, "tu é ")
    .replace(/\btu\s+eh\s+/giu, "tu é ")
    .replace(/\bconcerteza\b/giu, "com certeza")
    .replace(/\bcom certesa\b/giu, "com certeza")
    .replace(/\bporisso\b/giu, "por isso")
    .replace(/\bderrepente\b/giu, "de repente")
    .replace(/\bapartir\b/giu, "a partir")
    .replace(/\bafim de\b/giu, "a fim de")
    .replace(/\bagente\b(?=\s+(vai|foi|quer|precisa|pode|deve|tem|est[a\u00e1]|t[a\u00e1]))/giu, "a gente")
    .replace(/\bmim\b(?=\s+(vai|vou|posso|quero|preciso|fazer|mandar|enviar|corrigir))/giu, "eu")
    .replace(/\s+([,.!?;:])/g, "$1")
    .replace(/([,.!?;:])(?=\S)/g, "$1 ");
}

function capitalizeSentences(text) {
  let shouldCapitalize = true;

  return text.replace(/(\p{L})/gu, (letter) => {
    if (!shouldCapitalize) return letter;
    shouldCapitalize = false;
    return letter.toUpperCase();
  }).replace(/([.!?]\s+)(\p{L})/gu, (match, punctuation, letter) => {
    return `${punctuation}${letter.toUpperCase()}`;
  });
}

module.exports = {
  correctPortugueseText,
  getCorrectionSuggestions
};
