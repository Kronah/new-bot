"use strict";

const OLY_URL = process.env.OLY_RANKING_URL || "https://divolion.net/?page=oly_rank";
const CACHE_TTL_MS = Number(process.env.OLY_RANKING_CACHE_MS || 60 * 1000);
const FETCH_TIMEOUT_MS = Number(process.env.OLY_RANKING_TIMEOUT_MS || 12 * 1000);

let cache = null;

async function getOlyRanking(options = {}) {
  const now = Date.now();

  if (!options.force && cache && now - cache.fetchedAtMs < CACHE_TTL_MS) {
    return cache.data;
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);

  try {
    const response = await fetch(OLY_URL, {
      headers: {
        "User-Agent": "NovoBOT/1.0 WhatsApp bot"
      },
      signal: controller.signal
    });

    if (!response.ok) {
      throw new Error(`Erro HTTP ${response.status}`);
    }

    const html = await response.text();
    const data = parseOlyRanking(html);

    cache = {
      fetchedAtMs: now,
      data
    };

    return data;
  } finally {
    clearTimeout(timeout);
  }
}

function parseOlyRanking(html) {
  const rows = parseRows(html);
  const classes = groupByClass(rows);

  return {
    url: OLY_URL,
    fetchedAt: new Date().toISOString(),
    rows,
    classes
  };
}

function parseRows(html) {
  const tableMatch = String(html || "").match(/<h1[^>]*>\s*Grand Olympiad\s*<\/h1>[\s\S]*?<table\b[^>]*>([\s\S]*?)<\/table>/i) ||
    String(html || "").match(/<table\b[^>]*class=['"]default['"][^>]*>([\s\S]*?)<\/table>/i);

  if (!tableMatch) return [];

  const rows = [];
  const rowRegex = /<tr\b[^>]*>([\s\S]*?)<\/tr>/gi;
  let rowMatch;

  while ((rowMatch = rowRegex.exec(tableMatch[1])) !== null) {
    const cells = [...rowMatch[1].matchAll(/<td\b[^>]*>([\s\S]*?)<\/td>/gi)]
      .map((cell) => cleanCell(cell[1]));

    if (cells.length < 5) continue;

    const rank = parseRank(cells[0]);
    const name = cells[1];
    const className = cells[2];
    const points = Number(String(cells[3]).replace(/\D/g, "")) || 0;
    const clan = cells[4] || "-";

    if (!rank || !name || !className) continue;

    rows.push({
      rank,
      name,
      className,
      points,
      clan
    });
  }

  return rows;
}

function groupByClass(rows) {
  const grouped = new Map();

  for (const row of rows) {
    const key = row.className;
    const list = grouped.get(key) || [];
    list.push(row);
    grouped.set(key, list);
  }

  return Array.from(grouped.entries()).map(([className, players]) => ({
    className,
    players: players.sort((a, b) => a.rank - b.rank)
  }));
}

function formatOlyRanking(data, filter = "") {
  const classFilter = String(filter || "").trim();
  const selectedClasses = classFilter ? findMatchingClasses(data.classes, classFilter) : data.classes;
  const lines = [
    "\uD83C\uDFC6 *Olympiad Ranking - Divolion*",
    "\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501"
  ];

  if (!selectedClasses.length) {
    lines.push("");
    lines.push(`Classe nao encontrada: *${classFilter}*`);
    lines.push("");
    lines.push("Exemplo: !oly maestro");
    lines.push(`Classes disponiveis: ${data.classes.map((item) => item.className).join(", ")}`);
    return lines.join("\n");
  }

  if (classFilter) {
    lines.push(`\uD83D\uDD0E Filtro: *${selectedClasses[0].className}*`);
  } else {
    lines.push(`Top 3 de cada classe (${selectedClasses.length})`);
  }

  for (const group of selectedClasses) {
    appendClass(lines, group);
  }

  lines.push("");
  lines.push(`\uD83D\uDD52 Atualizado: ${formatDateTime(data.fetchedAt)}`);

  return lines.join("\n").trim();
}

function appendClass(lines, group) {
  const topPlayers = group.players.slice(0, 3);

  lines.push("");
  lines.push(`*${group.className}*`);
  lines.push("\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501");

  if (!topPlayers.length) {
    lines.push("Nenhum jogador encontrado.");
    return;
  }

  for (const player of topPlayers) {
    lines.push("");
    lines.push(`${getRankIcon(player.rank)} *${player.rank}\u00BA - ${player.name}*`);
    lines.push(`   \uD83E\uDDD9 Classe: ${player.className}`);
    lines.push(`   \u2B50 Pontos: *${player.points}*`);
    lines.push(`   \uD83D\uDEE1\uFE0F Clan: ${player.clan || "-"}`);
  }
}

function findMatchingClasses(classes, filter) {
  const normalizedFilter = normalize(filter);
  const exact = classes.find((group) => normalize(group.className) === normalizedFilter);

  if (exact) return [exact];

  const partial = classes.filter((group) => normalize(group.className).includes(normalizedFilter));
  if (partial.length) return partial.slice(0, 5);

  const compactFilter = normalizedFilter.replace(/\s+/g, "");
  const compact = classes.filter((group) => normalize(group.className).replace(/\s+/g, "").includes(compactFilter));

  return compact.slice(0, 5);
}

function parseRank(value) {
  const match = String(value || "").match(/\d+/);
  return match ? Number(match[0]) : 0;
}

function getRankIcon(rank) {
  if (rank === 1) return "\uD83E\uDD47";
  if (rank === 2) return "\uD83E\uDD48";
  if (rank === 3) return "\uD83E\uDD49";
  return "\uD83C\uDFC5";
}

function cleanCell(value) {
  return decodeHtmlEntities(String(value || "")
    .replace(/<[^>]+>/g, " ")
    .replace(/\s+/g, " ")
    .trim());
}

function decodeHtmlEntities(value) {
  return value
    .replace(/&nbsp;/gi, " ")
    .replace(/&ordm;/gi, "\u00BA")
    .replace(/&amp;/gi, "&")
    .replace(/&quot;/gi, "\"")
    .replace(/&#039;|&apos;/gi, "'")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">");
}

function normalize(value) {
  return String(value || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function formatDateTime(value) {
  return new Intl.DateTimeFormat("pt-BR", {
    dateStyle: "short",
    timeStyle: "short",
    timeZone: process.env.TZ || "America/Manaus"
  }).format(new Date(value));
}

module.exports = {
  formatOlyRanking,
  getOlyRanking,
  parseOlyRanking
};
