"use strict";

const fs = require("fs");
const path = require("path");

const { loadEnv } = require("./env");

loadEnv();

const DATA_DIR = process.env.DATA_DIR || path.join(process.cwd(), "data");
const INBOX_FILE = process.env.INBOX_FILE || path.join(DATA_DIR, "inbox.json");
const MAX_INBOX_ITEMS = Number(process.env.MAX_INBOX_ITEMS || 500);

function rememberInboundMessage(msg, text) {
  const jid = String(msg?.key?.remoteJid || "").trim();
  const cleanText = String(text || "").trim();

  if (!jid.endsWith("@g.us") || !cleanText || !msg?.key?.id) {
    return null;
  }

  const inbox = readInbox().filter((item) => item.id !== msg.key.id);
  const item = {
    id: msg.key.id,
    jid,
    participant: msg.key.participant || msg.participant || jid,
    pushName: msg.pushName || "Contato",
    text: cleanText,
    receivedAt: new Date().toISOString(),
    key: msg.key,
    message: msg.message
  };

  inbox.unshift(item);
  writeInbox(inbox.slice(0, MAX_INBOX_ITEMS));

  return item;
}

function getInbox({ jid, limit = 80 } = {}) {
  const cleanJid = String(jid || "").trim();
  const max = Math.max(1, Math.min(Number(limit) || 80, 200));

  return readInbox()
    .filter((item) => !cleanJid || item.jid === cleanJid)
    .slice(0, max)
    .map(toPublicMessage);
}

function findInboundMessage(id) {
  const cleanId = String(id || "").trim();
  if (!cleanId) return null;

  const item = readInbox().find((message) => message.id === cleanId);
  if (!item?.key || !item?.message) return null;

  return {
    key: item.key,
    message: item.message,
    pushName: item.pushName
  };
}

function toPublicMessage(item) {
  return {
    id: item.id,
    jid: item.jid,
    participant: item.participant,
    pushName: item.pushName,
    text: item.text,
    receivedAt: item.receivedAt
  };
}

function readInbox() {
  try {
    const data = JSON.parse(fs.readFileSync(INBOX_FILE, "utf8"));
    return Array.isArray(data) ? data : [];
  } catch (error) {
    return [];
  }
}

function writeInbox(inbox) {
  fs.mkdirSync(path.dirname(INBOX_FILE), { recursive: true });
  fs.writeFileSync(INBOX_FILE, JSON.stringify(inbox, null, 2));
}

module.exports = {
  findInboundMessage,
  getInbox,
  rememberInboundMessage
};
