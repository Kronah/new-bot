"use strict";

const fs = require("fs");
const path = require("path");

const DEFAULT_PATHS = [
  process.env.ZOEIRA_FILE ? path.resolve(process.cwd(), process.env.ZOEIRA_FILE) : "",
  path.resolve(process.cwd(), "zoeira.json"),
  path.resolve(process.cwd(), "data", "zoeira.json")
].filter(Boolean);

let cache = {
  filePath: "",
  mtimeMs: 0,
  items: [],
  provocations: [],
  genericAnswers: []
};

const PROVOCATION_KEYWORDS = [
  "bot burro",
  "burro",
  "lento",
  "ruim",
  "inutil",
  "lixo",
  "travado",
  "bugado",
  "fracasso",
  "otario",
  "idiota",
  "palhaco",
  "seu robo"
];

const DEFAULT_COMEBACKS = [
  "Zoeira aceita. Agora manda uma dificil pra eu te calar no argumento.",
  "Tentou me tiltar, ne? Bora, manda o desafio de verdade.",
  "Se a piada foi pra me derrubar, faltou dano critico.",
  "Resenha registrada. Agora fala serio que eu resolvo tambem.",
  "Boa tentativa de zoeira. Proximo round eu ganho no raciocinio."
];

function getZoeiraReply(text) {
  const normalizedText = normalizeText(text);
  if (!normalizedText) return "";

  const { items, provocations, genericAnswers } = loadItems();
  if (isProvocation(normalizedText)) {
    const pool = provocations.length ? provocations : (genericAnswers.length ? genericAnswers : DEFAULT_COMEBACKS);
    return pool[Math.floor(Math.random() * pool.length)];
  }

  if (!items.length) {
    if (genericAnswers.length) {
      return genericAnswers[Math.floor(Math.random() * genericAnswers.length)];
    }
    return "";
  }

  let best = null;
  for (const item of items) {
    const score = scoreMatch(normalizedText, item.patterns);
    if (score <= 0) continue;
    if (!best || score > best.score) {
      best = {
        score,
        answers: item.answers
      };
    }
  }

  if (!best || !best.answers.length) {
    if (genericAnswers.length) {
      return genericAnswers[Math.floor(Math.random() * genericAnswers.length)];
    }
    return "";
  }

  const index = Math.floor(Math.random() * best.answers.length);
  return best.answers[index];
}

function loadItems() {
  try {
    const resolved = resolveFilePath();
    if (!resolved) return [];

    const mtimeMs = fs.statSync(resolved).mtimeMs;
    if (cache.filePath === resolved && cache.mtimeMs === mtimeMs) {
      return {
        items: cache.items,
        provocations: cache.provocations,
        genericAnswers: cache.genericAnswers
      };
    }

    const fileContent = fs.readFileSync(resolved, "utf8");
    const parsed = parseZoeiraContent(fileContent);
    const items = normalizeEntries(parsed.rawForEntries);
    const provocations = normalizeProvocations(parsed.rawForProvocations);
    const genericAnswers = parsed.genericAnswers;

    cache = {
      filePath: resolved,
      mtimeMs,
      items,
      provocations,
      genericAnswers
    };

    return {
      items,
      provocations,
      genericAnswers
    };
  } catch (error) {
    console.error("Falha ao carregar zoeira.json:", error.message);
    return {
      items: [],
      provocations: [],
      genericAnswers: []
    };
  }
}

function parseZoeiraContent(content) {
  try {
    const raw = JSON.parse(content);
    const genericAnswers = extractGenericAnswersFromJson(raw);
    return {
      rawForEntries: raw,
      rawForProvocations: raw,
      genericAnswers
    };
  } catch (_) {
    const genericAnswers = extractGenericAnswersFromText(content);
    return {
      rawForEntries: [],
      rawForProvocations: {},
      genericAnswers
    };
  }
}

function extractGenericAnswersFromJson(raw) {
  const answers = [];

  if (Array.isArray(raw)) {
    for (const item of raw) {
      if (item && typeof item === "object" && Array.isArray(item.answers)) {
        answers.push(...item.answers);
      }
    }
  }

  return answers.map((item) => String(item || "").trim()).filter(Boolean);
}

function extractGenericAnswersFromText(content) {
  return String(content || "")
    .split(/\r?\n/)
    .map((line) => String(line || "").trim())
    .filter((line) => line.length >= 8)
    .filter((line) => !/^\d+\s/.test(line))
    .filter((line) => !line.endsWith(":"))
    .filter((line) => !/^[-_=~]+$/.test(line));
}

function normalizeProvocations(raw) {
  if (!raw || typeof raw !== "object") return [];

  const collect = (obj) => {
    if (!obj || typeof obj !== "object") return [];
    if (Array.isArray(obj.provocacoes)) return obj.provocacoes;
    if (Array.isArray(obj.comebacks)) return obj.comebacks;
    return [];
  };

  if (Array.isArray(raw)) {
    return raw
      .flatMap((item) => collect(item))
      .map((item) => String(item || "").trim())
      .filter(Boolean);
  }

  return collect(raw)
    .map((item) => String(item || "").trim())
    .filter(Boolean);
}

function isProvocation(normalizedText) {
  if (!normalizedText) return false;
  return PROVOCATION_KEYWORDS.some((keyword) => normalizedText.includes(keyword));
}

function resolveFilePath() {
  for (const filePath of DEFAULT_PATHS) {
    if (!filePath) continue;
    if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
      return filePath;
    }
  }
  return "";
}

function normalizeEntries(raw) {
  const rows = [];

  if (Array.isArray(raw)) {
    rows.push(...raw);
  } else if (raw && typeof raw === "object") {
    if (Array.isArray(raw.items)) {
      rows.push(...raw.items);
    } else {
      for (const [key, value] of Object.entries(raw)) {
        rows.push({ pattern: key, answer: value });
      }
    }
  }

  return rows
    .map((row) => {
      if (!row || typeof row !== "object") return null;

      const patternsRaw = [];
      if (Array.isArray(row.patterns)) patternsRaw.push(...row.patterns);
      if (typeof row.pattern === "string") patternsRaw.push(row.pattern);
      if (typeof row.trigger === "string") patternsRaw.push(row.trigger);
      if (Array.isArray(row.triggers)) patternsRaw.push(...row.triggers);

      const answersRaw = [];
      if (Array.isArray(row.answers)) answersRaw.push(...row.answers);
      if (typeof row.answer === "string") answersRaw.push(row.answer);
      if (typeof row.response === "string") answersRaw.push(row.response);
      if (Array.isArray(row.responses)) answersRaw.push(...row.responses);

      const patterns = patternsRaw.map(normalizeText).filter(Boolean);
      const answers = answersRaw.map((item) => String(item || "").trim()).filter(Boolean);

      if (!patterns.length || !answers.length) return null;

      return {
        patterns,
        answers
      };
    })
    .filter(Boolean);
}

function scoreMatch(normalizedText, patterns) {
  let best = 0;

  for (const pattern of patterns) {
    if (!pattern) continue;
    if (normalizedText === pattern) {
      return 1;
    }

    if (normalizedText.includes(pattern) || pattern.includes(normalizedText)) {
      const ratio = Math.min(pattern.length, normalizedText.length) / Math.max(pattern.length, normalizedText.length);
      best = Math.max(best, 0.6 + ratio * 0.3);
    }
  }

  return best;
}

function normalizeText(value) {
  return String(value || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

module.exports = {
  getZoeiraReply
};
