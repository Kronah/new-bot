"use strict";

const fs = require("fs");
const path = require("path");

const { loadEnv } = require("./env");
const {
  formatDateTimeInTimeZone,
  getAllBosses,
  getBossStatus,
  isAliveStatus,
  parseRespawnDate
} = require("./boss-status");
const { isGroupFeatureEnabled, setGroupFeatures } = require("./group-settings");

loadEnv();

const DATA_DIR = process.env.DATA_DIR || path.join(process.cwd(), "data");
const ALERTS_FILE = process.env.BOSS_ALERTS_FILE || path.join(DATA_DIR, "boss-alerts.json");
const CHECK_INTERVAL_MS = Number(process.env.BOSS_ALERT_INTERVAL_MS || 5 * 60 * 1000);
const ALERT_WINDOW_MINUTES = Number(process.env.BOSS_ALERT_WINDOW_MINUTES || 60);
const ALERT_STEP_MINUTES = Number(process.env.BOSS_ALERT_STEP_MINUTES || 20);
const LOCAL_TIMEZONE = process.env.BOSS_ALERT_LOCAL_TIMEZONE || process.env.TZ || "America/Manaus";

let interval = null;
let running = false;

function startBossAlerts(sock) {
  if (interval) return;

  interval = setInterval(() => {
    runBossAlertCheck(sock).catch((error) => {
      console.error("Erro nos alertas de boss:", error.message);
    });
  }, CHECK_INTERVAL_MS);

  setTimeout(() => {
    runBossAlertCheck(sock).catch((error) => {
      console.error("Erro nos alertas de boss:", error.message);
    });
  }, 10 * 1000);
}

async function runBossAlertCheck(sock) {
  if (running) return;
  running = true;

  try {
    const state = readAlertState();

    if (!state.subscribers.length) return;

    const data = await getBossStatus({ force: true });
    const messages = buildAlertMessages(data, state, new Date());

    for (const jid of state.subscribers.filter((item) => isGroupFeatureEnabled(item, "alerts"))) {
      for (const message of messages) {
        await sock.sendMessage(jid, { text: message });
      }
    }

    writeAlertState(state);
  } finally {
    running = false;
  }
}

function buildAlertMessages(data, state, now = new Date()) {
  const messages = [];

  for (const boss of getAllBosses(data)) {
    const statusAlive = isAliveStatus(boss.status);
    const respawnAt = parseRespawnDate(boss.respawn);
    const noticeKey = getNoticeKey(boss);
    const notice = state.notices[noticeKey] || {};

    if (statusAlive) {
      if (!notice.aliveSent) {
        messages.push(formatAliveAlert(boss));
        state.notices[noticeKey] = {
          ...notice,
          aliveSent: true,
          lastStatus: "alive",
          updatedAt: now.toISOString()
        };
      }

      continue;
    }

    if (!respawnAt) {
      continue;
    }

    const minutesUntil = Math.ceil((respawnAt.getTime() - now.getTime()) / 60000);

    if (minutesUntil > ALERT_WINDOW_MINUTES || minutesUntil <= 0) {
      continue;
    }

    const bucket = Math.ceil(minutesUntil / ALERT_STEP_MINUTES) * ALERT_STEP_MINUTES;

    if (notice.lastCountdownBucket === bucket) {
      continue;
    }

    messages.push(formatCountdownAlert(boss, bucket, respawnAt));
    state.notices[noticeKey] = {
      ...notice,
      lastCountdownBucket: bucket,
      lastStatus: "dead",
      updatedAt: now.toISOString()
    };
  }

  return messages;
}

function subscribeBossAlerts(jid) {
  const state = readAlertState();

  if (!state.subscribers.includes(jid)) {
    state.subscribers.push(jid);
    writeAlertState(state);
  }

  if (String(jid || "").endsWith("@g.us")) {
    setGroupFeatures(jid, { alerts: true });
  }

  return state.subscribers.length;
}

function unsubscribeBossAlerts(jid) {
  const state = readAlertState();
  state.subscribers = state.subscribers.filter((item) => item !== jid);
  writeAlertState(state);

  if (String(jid || "").endsWith("@g.us")) {
    setGroupFeatures(jid, { alerts: false });
  }

  return state.subscribers.length;
}

function isSubscribedToBossAlerts(jid) {
  return readAlertState().subscribers.includes(jid);
}

function readAlertState() {
  try {
    const raw = fs.readFileSync(ALERTS_FILE, "utf8");
    const state = JSON.parse(raw);

    return {
      subscribers: Array.isArray(state.subscribers) ? state.subscribers : [],
      notices: state.notices && typeof state.notices === "object" ? state.notices : {}
    };
  } catch (error) {
    return {
      subscribers: [],
      notices: {}
    };
  }
}

function writeAlertState(state) {
  fs.mkdirSync(path.dirname(ALERTS_FILE), { recursive: true });
  fs.writeFileSync(ALERTS_FILE, JSON.stringify(state, null, 2));
}

function formatCountdownAlert(boss, minutes, respawnAt) {
  return [
    "\u23F0 *Alerta de Boss*",
    "\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501",
    `${getCategoryIcon(boss.category)} *${boss.name}*`,
    `\uD83D\uDCC5 Brasilia: ${boss.respawn || "-"}`,
    `\uD83D\uDCCD Manaus: ${formatDateTimeInTimeZone(respawnAt, LOCAL_TIMEZONE)}`,
    `\u23F3 Falta cerca de *${minutes} min*`,
    "\uD83D\uDD34 Status atual: *Morto*"
  ].join("\n");
}

function formatAliveAlert(boss) {
  return [
    "\uD83D\uDFE2 *Boss Vivo!*",
    "\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501",
    `${getCategoryIcon(boss.category)} *${boss.name}*`,
    `\u23F1\uFE0F Brasilia: ${boss.respawn || "-"}`,
    "\uD83D\uDCCD Local: Vivo",
    "\uD83D\uDCCA Status: *Vivo*"
  ].join("\n");
}

function getNoticeKey(boss) {
  return `${boss.category}:${boss.name}:${boss.respawn || "sem-respawn"}`;
}

function getCategoryIcon(category) {
  return category === "Bosses" ? "\uD83D\uDC51" : "\u2694\uFE0F";
}

module.exports = {
  buildAlertMessages,
  isSubscribedToBossAlerts,
  startBossAlerts,
  subscribeBossAlerts,
  unsubscribeBossAlerts
};
