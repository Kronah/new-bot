"use strict";

const { loadEnv } = require("./env");

loadEnv();

const GOOGLE_SEARCH_API_KEY = process.env.GOOGLE_SEARCH_API_KEY || process.env.GOOGLE_CSE_API_KEY || "";
const GOOGLE_SEARCH_CX = process.env.GOOGLE_SEARCH_CX || process.env.GOOGLE_CSE_CX || "";
const GOOGLE_SEARCH_NUM = Math.max(1, Math.min(Number(process.env.GOOGLE_SEARCH_NUM || 3), 5));
const GOOGLE_SEARCH_TIMEOUT_MS = Number(process.env.GOOGLE_SEARCH_TIMEOUT_MS || 7000);

function isWebSearchConfigured() {
  return Boolean(GOOGLE_SEARCH_API_KEY && GOOGLE_SEARCH_CX);
}

async function searchWebAnswer(query) {
  const q = String(query || "").trim();
  if (!q) return null;

  if (!isWebSearchConfigured()) {
    const googleAnswer = await searchGoogleHtmlAnswer(q);
    if (googleAnswer) return googleAnswer;
    return searchWikipediaAnswer(q);
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), GOOGLE_SEARCH_TIMEOUT_MS);

  try {
    const url = new URL("https://www.googleapis.com/customsearch/v1");
    url.searchParams.set("key", GOOGLE_SEARCH_API_KEY);
    url.searchParams.set("cx", GOOGLE_SEARCH_CX);
    url.searchParams.set("q", q);
    url.searchParams.set("num", String(GOOGLE_SEARCH_NUM));
    url.searchParams.set("hl", "pt-BR");
    url.searchParams.set("safe", "active");

    const response = await fetch(url, { signal: controller.signal });
    if (!response.ok) {
      const googleAnswer = await searchGoogleHtmlAnswer(q);
      if (googleAnswer) return googleAnswer;
      return searchWikipediaAnswer(q);
    }

    const data = await response.json().catch(() => ({}));
    const items = Array.isArray(data.items) ? data.items : [];
    if (!items.length) {
      const googleAnswer = await searchGoogleHtmlAnswer(q);
      if (googleAnswer) return googleAnswer;
      return searchWikipediaAnswer(q);
    }

    for (const item of items) {
      const cleaned = cleanSnippet(item.snippet || item.title || "");
      if (cleaned) return cleaned;
    }

    const googleAnswer = await searchGoogleHtmlAnswer(q);
    if (googleAnswer) return googleAnswer;
    return searchWikipediaAnswer(q);
  } catch (error) {
    const googleAnswer = await searchGoogleHtmlAnswer(q);
    if (googleAnswer) return googleAnswer;
    return searchWikipediaAnswer(q);
  } finally {
    clearTimeout(timeout);
  }
}

async function searchGoogleHtmlAnswer(query) {
  const q = String(query || "").trim();
  if (!q) return null;

  const attempts = [
    `https://www.google.com/search?hl=pt-BR&q=${encodeURIComponent(q)}`,
    `https://r.jina.ai/http://www.google.com/search?hl=pt-BR&q=${encodeURIComponent(q)}`
  ];

  for (const url of attempts) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), GOOGLE_SEARCH_TIMEOUT_MS);

    try {
      const response = await fetch(url, {
        signal: controller.signal,
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
        }
      });

      if (!response.ok) continue;

      const html = await response.text().catch(() => "");
      const snippet = extractGoogleSnippet(html);
      if (snippet) return snippet;
    } catch (error) {
      continue;
    } finally {
      clearTimeout(timeout);
    }
  }

  return null;
}

function extractGoogleSnippet(html) {
  const content = String(html || "");
  if (!content) return "";

  const patterns = [
    /<div class="BNeawe s3v9rd AP7Wnd">([\s\S]*?)<\/div>/i,
    /<span class="aCOpRe">([\s\S]*?)<\/span>/i,
    /"snippet"\s*:\s*"([^"]{40,500})"/i,
    /"description"\s*:\s*"([^"]{40,500})"/i
  ];

  for (const pattern of patterns) {
    const match = content.match(pattern);
    if (!match?.[1]) continue;

    const cleaned = cleanSnippet(decodeHtml(stripHtml(match[1])));
    if (cleaned && cleaned.length >= 30) return cleaned;
  }

  return "";
}

function stripHtml(text) {
  return String(text || "")
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ");
}

function decodeHtml(text) {
  return String(text || "")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/\\u003c/g, "<")
    .replace(/\\u003e/g, ">")
    .replace(/\\u0026/g, "&");
}

async function searchWikipediaAnswer(query) {
  const q = String(query || "").trim();
  if (!q) return null;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), GOOGLE_SEARCH_TIMEOUT_MS);

  try {
    const title = await findWikipediaTitle(buildCandidateQueries(q), controller.signal);
    if (!title) return null;

    const summaryUrl = `https://pt.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(title)}`;
    const summaryResponse = await fetch(summaryUrl, {
      signal: controller.signal,
      headers: {
        "User-Agent": "NovoBot/1.0"
      }
    });

    if (!summaryResponse.ok) return null;

    const summary = await summaryResponse.json().catch(() => ({}));
    const extract = cleanSnippet(summary.extract || "");
    return extract || null;
  } catch (error) {
    return null;
  } finally {
    clearTimeout(timeout);
  }
}

async function findWikipediaTitle(queries, signal) {
  for (const query of queries) {
    const searchUrl = new URL("https://pt.wikipedia.org/w/api.php");
    searchUrl.searchParams.set("action", "opensearch");
    searchUrl.searchParams.set("search", query);
    searchUrl.searchParams.set("limit", "1");
    searchUrl.searchParams.set("namespace", "0");
    searchUrl.searchParams.set("format", "json");

    const response = await fetch(searchUrl, {
      signal,
      headers: {
        "User-Agent": "NovoBot/1.0"
      }
    });

    if (!response.ok) continue;

    const data = await response.json().catch(() => []);
    const title = Array.isArray(data?.[1]) ? data[1][0] : "";
    if (title) return title;
  }

  return "";
}

function buildCandidateQueries(query) {
  const normalized = String(query || "")
    .toLowerCase()
    .replace(/[?!.;,]/g, " ")
    .replace(/\s+/g, " ")
    .trim();

  const candidates = [query, normalized];
  const discoverMatch = normalized.match(/quem\s+descobriu\s+(?:o|a)?\s*(.+)/i);
  const whoMatch = normalized.match(/quem\s+foi\s+(.+)/i);
  const whatIsMatch = normalized.match(/o\s+que\s+e\s+(.+)/i);

  if (discoverMatch?.[1]) {
    const term = discoverMatch[1].trim();
    const titledTerm = term.charAt(0).toUpperCase() + term.slice(1);
    candidates.push(`Descobrimento do ${titledTerm}`);
    candidates.push(titledTerm);
  }

  if (normalized.includes("brasil")) {
    candidates.push("Descobrimento do Brasil");
    candidates.push("Pedro Álvares Cabral");
  }

  if (whoMatch?.[1]) {
    const term = whoMatch[1].trim();
    const titled = term.charAt(0).toUpperCase() + term.slice(1);
    candidates.push(titled);
    candidates.push(`${titled} biografia`);
  }

  if (whatIsMatch?.[1]) {
    const term = whatIsMatch[1].trim();
    const titled = term.charAt(0).toUpperCase() + term.slice(1);
    candidates.push(titled);
  }

  // Generic cleanup for question forms.
  candidates.push(normalized.replace(/^(quem\s+foi|quem\s+e|o\s+que\s+e|o\s+que\s+foi)\s+/i, "").trim());

  return [...new Set(candidates.filter(Boolean))];
}

function cleanSnippet(text) {
  return String(text || "")
    .replace(/\s+/g, " ")
    .replace(/\s([,.;!?])/g, "$1")
    .trim();
}

module.exports = {
  isWebSearchConfigured,
  searchWebAnswer
};
