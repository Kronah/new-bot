"use strict";

const fs = require("fs");
const path = require("path");

const { loadEnv } = require("./env");

loadEnv();

const DATA_DIR = process.env.DATA_DIR || path.join(process.cwd(), "data");
const GROUPS_FILE = process.env.GROUPS_FILE || path.join(DATA_DIR, "groups.json");
const GROUP_SETTINGS_FILE = process.env.GROUP_SETTINGS_FILE || path.join(DATA_DIR, "group-settings.json");
const DEFAULT_FEATURES = {
  bot: true,
  ia: true,
  zoeira: true,
  boss: true,
  oly: true,
  alerts: false
};

function readKnownGroups() {
  try {
    const raw = fs.readFileSync(GROUPS_FILE, "utf8");
    const groups = JSON.parse(raw);

    return Array.isArray(groups) ? groups : [];
  } catch (error) {
    return [];
  }
}

function writeKnownGroups(groups) {
  ensureDataDir();
  fs.writeFileSync(GROUPS_FILE, JSON.stringify(sortGroups(groups), null, 2));
}

function upsertKnownGroup(group) {
  if (!group?.jid) return;

  const groups = readKnownGroups();
  const index = groups.findIndex((item) => item.jid === group.jid);
  const next = {
    jid: group.jid,
    name: group.name || group.subject || group.jid,
    participants: Number(group.participants || 0),
    updatedAt: new Date().toISOString()
  };

  if (index === -1) {
    groups.push(next);
  } else {
    groups[index] = {
      ...groups[index],
      ...next
    };
  }

  writeKnownGroups(groups);
}

async function updateKnownGroupsFromSocket(sock) {
  if (!sock?.groupFetchAllParticipating) return [];

  const allGroups = await sock.groupFetchAllParticipating();
  const groups = Object.values(allGroups || {}).map((group) => ({
    jid: group.id,
    name: group.subject || group.id,
    participants: Array.isArray(group.participants) ? group.participants.length : 0,
    updatedAt: new Date().toISOString()
  }));

  writeKnownGroups(groups);
  return groups;
}

function readGroupSettings() {
  try {
    const raw = fs.readFileSync(GROUP_SETTINGS_FILE, "utf8");
    const settings = JSON.parse(raw);

    return settings && typeof settings === "object" ? settings : {};
  } catch (error) {
    return {};
  }
}

function writeGroupSettings(settings) {
  ensureDataDir();
  fs.writeFileSync(GROUP_SETTINGS_FILE, JSON.stringify(settings, null, 2));
}

function getGroupFeatures(jid) {
  const settings = readGroupSettings();
  return {
    ...DEFAULT_FEATURES,
    ...(settings[jid] || {})
  };
}

function setGroupFeatures(jid, features) {
  const settings = readGroupSettings();
  const current = getGroupFeatures(jid);

  settings[jid] = {
    ...current,
    ...normalizeFeatures(features),
    updatedAt: new Date().toISOString()
  };

  writeGroupSettings(settings);
  return settings[jid];
}

function isGroupFeatureEnabled(jid, feature) {
  if (!String(jid || "").endsWith("@g.us")) return true;

  const features = getGroupFeatures(jid);
  return features.bot !== false && features[feature] !== false;
}

function getGroupsWithSettings() {
  const settings = readGroupSettings();

  return readKnownGroups().map((group) => ({
    ...group,
    features: {
      ...DEFAULT_FEATURES,
      ...(settings[group.jid] || {})
    }
  }));
}

function normalizeFeatures(features) {
  const next = {};

  for (const key of Object.keys(features || {})) {
    if (!(key in DEFAULT_FEATURES)) continue;

    if (features[key] !== undefined) {
      next[key] = toBoolean(features[key]);
    }
  }

  return next;
}

function toBoolean(value) {
  if (typeof value === "boolean") return value;
  if (typeof value === "number") return value !== 0;

  const normalized = String(value || "").trim().toLowerCase();
  if (["false", "0", "off", "nao", "não"].includes(normalized)) return false;
  if (["true", "1", "on", "sim"].includes(normalized)) return true;

  return Boolean(value);
}

function sortGroups(groups) {
  return [...groups].sort((a, b) => String(a.name || "").localeCompare(String(b.name || ""), "pt-BR"));
}

function ensureDataDir() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

module.exports = {
  getGroupFeatures,
  getGroupsWithSettings,
  isGroupFeatureEnabled,
  readKnownGroups,
  setGroupFeatures,
  updateKnownGroupsFromSocket,
  upsertKnownGroup
};
