"use strict";

const BOSS_URL = process.env.BOSS_STATUS_URL || "https://divolion.net/?page=boss";
const CACHE_TTL_MS = Number(process.env.BOSS_STATUS_CACHE_MS || 60 * 1000);
const FETCH_TIMEOUT_MS = Number(process.env.BOSS_STATUS_TIMEOUT_MS || 12 * 1000);
const SITE_TIMEZONE = process.env.BOSS_STATUS_TIMEZONE || "America/Sao_Paulo";
const LOCAL_TIMEZONE = process.env.BOSS_ALERT_LOCAL_TIMEZONE || process.env.TZ || "America/Manaus";

let cache = null;

async function getBossStatus(options = {}) {
  const now = Date.now();

  if (!options.force && cache && now - cache.fetchedAtMs < CACHE_TTL_MS) {
    return cache.data;
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);

  try {
    const response = await fetch(BOSS_URL, {
      headers: {
        "User-Agent": "NovoBOT/1.0 WhatsApp bot"
      },
      signal: controller.signal
    });

    if (!response.ok) {
      throw new Error(`Erro HTTP ${response.status}`);
    }

    const html = await response.text();
    const data = parseBossStatus(html);

    cache = {
      fetchedAtMs: now,
      data
    };

    return data;
  } finally {
    clearTimeout(timeout);
  }
}

function parseBossStatus(html) {
  const sections = {
    epic: parseSection(html, "Epic Bosses"),
    raid: parseSection(html, "Raid Bosses")
  };

  return {
    url: BOSS_URL,
    fetchedAt: new Date().toISOString(),
    sections
  };
}

function parseSection(html, title) {
  const escapedTitle = escapeRegExp(title);
  const sectionMatch = html.match(new RegExp(`<h2[^>]*>\\s*${escapedTitle}\\s*<\\/h2>[\\s\\S]*?<table[^>]*>([\\s\\S]*?)<\\/table>`, "i"));

  if (!sectionMatch) return [];

  const rows = [];
  const rowRegex = /<tr\b[^>]*>([\s\S]*?)<\/tr>/gi;
  let rowMatch;

  while ((rowMatch = rowRegex.exec(sectionMatch[1])) !== null) {
    const cells = [...rowMatch[1].matchAll(/<td\b[^>]*>([\s\S]*?)<\/td>/gi)]
      .map((cell) => cleanCell(cell[1]));

    if (cells.length < 4) continue;

    rows.push({
      name: cells[0],
      level: cells[1],
      status: cells[2],
      respawn: cells[3]
    });
  }

  return rows;
}

function formatBossStatus(data, filter = "all") {
  const normalizedFilter = String(filter || "all").toLowerCase();
  const lines = [
    "\uD83D\uDCDC *Boss Status - Divolion*",
    "\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501"
  ];

  if (normalizedFilter === "all" || normalizedFilter === "epic") {
    appendSection(lines, "\uD83D\uDC51 Bosses", data.sections.epic);
  }

  if (normalizedFilter === "all" || normalizedFilter === "raid") {
    if (lines[lines.length - 1] !== "") lines.push("");
    appendSection(lines, "\u2694\uFE0F Raid Bosses", data.sections.raid);
  }

  lines.push("");
  lines.push(`\uD83D\uDD52 Atualizado: ${formatDateTime(data.fetchedAt)}`);

  return lines.join("\n").trim();
}

function appendSection(lines, title, bosses) {
  lines.push(`*${title} (${bosses.length})*`);
  lines.push("\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501");

  if (!bosses.length) {
    lines.push("Nenhum boss encontrado.");
    return;
  }

  for (const boss of bosses) {
    const status = translateStatus(boss.status);
    const statusIcon = getStatusIcon(status);

    lines.push("");
    lines.push(`${statusIcon} *${boss.name}*`);
    lines.push(`   \u23F1\uFE0F Respawn (Brasilia): ${boss.respawn || "-"}`);
    lines.push(`   \uD83D\uDCCD Local: ${status}`);
    lines.push(`   \uD83D\uDCCA Status: *${status}*`);
  }
}

function getAllBosses(data) {
  return [
    ...data.sections.epic.map((boss) => ({ ...boss, category: "Bosses" })),
    ...data.sections.raid.map((boss) => ({ ...boss, category: "Raid Bosses" }))
  ];
}

function parseRespawnDate(respawn) {
  const match = String(respawn || "").match(/^(\d{2})\/(\d{2})\/(\d{4})\s+(\d{2}):(\d{2})$/);

  if (!match) return null;

  const [, day, month, year, hour, minute] = match;
  return zonedDateToUtc({
    year: Number(year),
    month: Number(month),
    day: Number(day),
    hour: Number(hour),
    minute: Number(minute),
    timeZone: SITE_TIMEZONE
  });
}

function translateStatus(status) {
  const normalized = String(status || "").trim().toLowerCase();

  if (normalized === "dead") return "Morto";
  if (normalized === "alive") return "Vivo";

  return status || "-";
}

function isAliveStatus(status) {
  return translateStatus(status).toLowerCase() === "vivo";
}

function getStatusIcon(status) {
  return String(status).toLowerCase() === "vivo" ? "\uD83D\uDFE2" : "\uD83D\uDD34";
}

function cleanCell(value) {
  return decodeHtmlEntities(String(value || "")
    .replace(/<[^>]+>/g, " ")
    .replace(/\s+/g, " ")
    .trim());
}

function decodeHtmlEntities(value) {
  return value
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&quot;/gi, "\"")
    .replace(/&#039;|&apos;/gi, "'")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">");
}

function formatDateTime(value) {
  return new Intl.DateTimeFormat("pt-BR", {
    dateStyle: "short",
    timeStyle: "short",
    timeZone: process.env.TZ || "America/Manaus"
  }).format(new Date(value));
}

function formatDateTimeInTimeZone(value, timeZone = LOCAL_TIMEZONE) {
  return new Intl.DateTimeFormat("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
    timeZone
  }).format(new Date(value)).replace(",", "");
}

function zonedDateToUtc({ year, month, day, hour, minute, timeZone }) {
  const utcGuess = new Date(Date.UTC(year, month - 1, day, hour, minute, 0, 0));
  const parts = getDateTimeParts(utcGuess, timeZone);
  const diffMs = Date.UTC(year, month - 1, day, hour, minute, 0, 0) -
    Date.UTC(parts.year, parts.month - 1, parts.day, parts.hour, parts.minute, 0, 0);

  return new Date(utcGuess.getTime() + diffMs);
}

function getDateTimeParts(date, timeZone) {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false
  }).formatToParts(date);

  const values = Object.fromEntries(parts.map((part) => [part.type, part.value]));

  return {
    year: Number(values.year),
    month: Number(values.month),
    day: Number(values.day),
    hour: Number(values.hour),
    minute: Number(values.minute)
  };
}

function escapeRegExp(value) {
  return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

module.exports = {
  formatBossStatus,
  getAllBosses,
  getBossStatus,
  formatDateTimeInTimeZone,
  isAliveStatus,
  parseBossStatus,
  parseRespawnDate
};
