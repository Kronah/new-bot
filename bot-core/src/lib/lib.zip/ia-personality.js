"use strict";

const fs = require("fs");
const path = require("path");

const { loadEnv } = require("./env");

loadEnv();

const DATA_DIR = process.env.DATA_DIR || path.join(process.cwd(), "data");
const IA_CONFIG_FILE = process.env.IA_CONFIG_FILE || path.join(DATA_DIR, "ia-config.json");

const PERSONALITIES = [
  {
    id: "educada",
    name: "Educada",
    description: "Responde com respeito, calma e cordialidade.",
    prompt: "Seja educado, respeitoso, cordial e paciente."
  },
  {
    id: "direta",
    name: "Direta",
    description: "Vai direto ao ponto, sem enrolar.",
    prompt: "Seja direto, objetivo e evite respostas longas quando uma resposta curta resolver."
  },
  {
    id: "tecnica",
    name: "Tecnica",
    description: "Explica com precisao e detalhes praticos.",
    prompt: "Use raciocinio tecnico, explique passos claros e seja preciso nos termos."
  },
  {
    id: "amigavel",
    name: "Amigavel",
    description: "Tom leve, proximo e facil de conversar.",
    prompt: "Use um tom amigavel, proximo e natural, como uma conversa de WhatsApp."
  },
  {
    id: "engracada",
    name: "Engracada",
    description: "Leve, bem humorada, sem exagerar.",
    prompt: "Pode usar humor leve e discreto, sem atrapalhar a utilidade da resposta."
  },
  {
    id: "zoeira",
    name: "Zoeira Pesada",
    description: "Doidona, bagunceira, debochada e com energia de resenha gamer.",
    prompt: "Use humor bem bagunceiro, caotico e debochado, com energia de resenha gamer. Pode tirar onda, chamar de noob, ruim, bagre, perdido, inimigo do teclado e usar provocacao brincalhona. Evite xingamento discriminatorio, ameaca, perseguicao, humilhacao pesada ou desumanizacao."
  },
  {
    id: "possessiva",
    name: "Possessiva Autoritaria",
    description: "Mandona, protetora e cheia de controle.",
    prompt: "Use um tom autoritario, protetor e possessivo de brincadeira. Fale com firmeza, como quem assume o comando, mas mantenha respeito e nao incentive controle abusivo real."
  },
  {
    id: "soberana",
    name: "Soberana",
    description: "Dominante, egocentrica e cheia de superioridade teatral.",
    prompt: "Use uma postura soberana, dominante, teatralmente egocentrica e confiante, como quem se acha acima da situacao. Pode soar rancoroso e imponente de forma dramatica, mas sem ofensas pesadas, discriminacao ou ameacas."
  },
  {
    id: "rpg",
    name: "RPG Gamer",
    description: "Tom gamer/RPG, bom para Lineage e clans.",
    prompt: "Use linguagem gamer/RPG quando fizer sentido, especialmente para Lineage, clans, boss e olympiad."
  },
  {
    id: "vendedora",
    name: "Vendedora",
    description: "Foco em convencer, explicar beneficios e chamar para acao.",
    prompt: "Quando houver produto, servico ou convite, destaque beneficios e finalize com uma chamada para acao."
  },
  {
    id: "suporte",
    name: "Suporte",
    description: "Ajuda a resolver problemas com perguntas objetivas.",
    prompt: "Atue como suporte: diagnostique, pergunte o necessario e proponha passos de solucao."
  },
  {
    id: "professora",
    name: "Professora",
    description: "Ensina com exemplos simples.",
    prompt: "Ensine de forma didatica, com exemplos simples e progressivos."
  },
  {
    id: "moderadora",
    name: "Moderadora",
    description: "Mantem ordem, evita brigas e linguagem pesada.",
    prompt: "Ajude a manter o respeito, reduza conflitos e evite incentivar brigas ou ofensas."
  },
  {
    id: "formal",
    name: "Formal",
    description: "Mais profissional e cuidadosa.",
    prompt: "Use linguagem formal, profissional e bem organizada."
  },
  {
    id: "curta",
    name: "Curta",
    description: "Respostas pequenas para grupo.",
    prompt: "Prefira respostas curtas, com no maximo poucos paragrafos, a menos que peçam detalhes."
  }
];

const DEFAULT_CONFIG = {
  selected: ["educada", "direta", "suporte"],
  customPrompt: "",
  groupProfiles: [],
  adminProfiles: [],
  scheduleProfile: {
    enabled: false,
    start: "08:00",
    end: "18:00",
    selected: [],
    customPrompt: ""
  },
  updatedAt: null
};

function getIaConfig() {
  return {
    personalities: PERSONALITIES,
    config: readConfig()
  };
}

function saveIaConfig(input = {}) {
  const selected = normalizeSelected(input.selected, DEFAULT_CONFIG.selected);
  const groupProfiles = normalizeProfiles(input.groupProfiles);
  const adminProfiles = normalizeProfiles(input.adminProfiles);
  const scheduleProfile = normalizeScheduleProfile(input.scheduleProfile);

  const config = {
    selected: Array.from(new Set(selected)),
    customPrompt: String(input.customPrompt || "").trim().slice(0, 2000),
    groupProfiles,
    adminProfiles,
    scheduleProfile,
    updatedAt: new Date().toISOString()
  };

  writeConfig(config);
  return config;
}

function buildIaSystemPrompt(context = {}) {
  const profile = resolveProfile(readConfig(), context);
  const selected = PERSONALITIES.filter((item) => profile.selected.includes(item.id));
  const lines = [
    "Voce e um assistente pessoal livre no WhatsApp.",
    "Responda em portugues do Brasil.",
    "Nao invente dados. Quando faltar informacao, faca uma pergunta objetiva.",
    "Personalidades ativas podem ser mescladas; combine todas sem contradicao.",
    `Perfil ativo: ${profile.label}`
  ];

  for (const personality of selected) {
    lines.push(`- ${personality.name}: ${personality.prompt}`);
  }

  if (profile.customPrompt) {
    lines.push(`Instrucao extra do administrador: ${profile.customPrompt}`);
  }

  return lines.join("\n");
}

function getIaPersonalityLabel(context = {}) {
  const profile = resolveProfile(readConfig(), context);
  return PERSONALITIES
    .filter((item) => profile.selected.includes(item.id))
    .map((item) => item.name)
    .join(" + ") || "Padrao";
}

function adaptAnswerToPersonality(answer, context = {}) {
  const profile = resolveProfile(readConfig(), context);
  const selected = new Set(profile.selected || []);
  let text = String(answer || "").trim();

  if (!text) return text;

  if (selected.has("curta")) {
    text = limitSentences(text, 2);
  }

  if (selected.has("formal")) {
    text = text
      .replace(/\bvoce\b/gi, "você")
      .replace(/\bVoce\b/g, "Você");
  }

  if (selected.has("tecnica") && !/^Resumo tecnico:/i.test(text)) {
    text = `Resumo tecnico: ${text}`;
  }

  if (selected.has("amigavel") && !/^Claro[!,.]?/i.test(text)) {
    text = `Claro! ${text}`;
  }

  if (selected.has("engracada") || selected.has("zoeira")) {
    text = `${text} 😄`;
  }

  return text;
}

function limitSentences(text, maxSentences) {
  const matches = String(text || "").match(/[^.!?]+[.!?]?/g) || [];
  const sliced = matches.slice(0, Math.max(1, maxSentences)).join(" ").trim();
  return sliced || text;
}

function readConfig() {
  try {
    const data = JSON.parse(fs.readFileSync(IA_CONFIG_FILE, "utf8"));
    const selected = normalizeSelected(data?.selected, DEFAULT_CONFIG.selected);
    const groupProfiles = normalizeProfiles(data?.groupProfiles);
    const adminProfiles = normalizeProfiles(data?.adminProfiles);
    const scheduleProfile = normalizeScheduleProfile(data?.scheduleProfile);

    return {
      ...DEFAULT_CONFIG,
      ...(data && typeof data === "object" ? data : {}),
      selected,
      groupProfiles,
      adminProfiles,
      scheduleProfile
    };
  } catch (error) {
    return DEFAULT_CONFIG;
  }
}

function resolveProfile(config, context) {
  const fallback = {
    label: "global",
    selected: normalizeSelected(config.selected, DEFAULT_CONFIG.selected),
    customPrompt: String(config.customPrompt || "").trim()
  };
  const jid = String(context?.jid || "").trim();
  const senderJid = String(context?.senderJid || "").trim();
  const isAdmin = Boolean(context?.isAdmin);

  if (isAdmin && senderJid) {
    const adminProfile = (config.adminProfiles || []).find((item) => item.id === senderJid);
    if (adminProfile) {
      return {
        label: `admin:${senderJid}`,
        selected: adminProfile.selected,
        customPrompt: adminProfile.customPrompt
      };
    }
  }

  if (jid && jid.endsWith("@g.us")) {
    const groupProfile = (config.groupProfiles || []).find((item) => item.id === jid);
    if (groupProfile) {
      return {
        label: `grupo:${jid}`,
        selected: groupProfile.selected,
        customPrompt: groupProfile.customPrompt
      };
    }
  }

  if (isScheduleActive(config.scheduleProfile)) {
    return {
      label: `horario:${config.scheduleProfile.start}-${config.scheduleProfile.end}`,
      selected: config.scheduleProfile.selected,
      customPrompt: config.scheduleProfile.customPrompt
    };
  }

  return fallback;
}

function normalizeProfiles(input) {
  if (!Array.isArray(input)) return [];

  return input
    .map((item) => ({
      id: String(item?.id || "").trim(),
      selected: normalizeSelected(item?.selected, []),
      customPrompt: String(item?.customPrompt || "").trim().slice(0, 1000)
    }))
    .filter((item) => item.id && item.selected.length);
}

function normalizeScheduleProfile(input) {
  const source = input && typeof input === "object" ? input : {};
  return {
    enabled: Boolean(source.enabled),
    start: normalizeTime(source.start) || DEFAULT_CONFIG.scheduleProfile.start,
    end: normalizeTime(source.end) || DEFAULT_CONFIG.scheduleProfile.end,
    selected: normalizeSelected(source.selected, []),
    customPrompt: String(source.customPrompt || "").trim().slice(0, 1000)
  };
}

function normalizeSelected(input, fallback) {
  const list = Array.isArray(input) ? input : fallback;
  return Array.from(new Set(
    list.filter((id) => PERSONALITIES.some((item) => item.id === id))
  ));
}

function normalizeTime(value) {
  const match = String(value || "").trim().match(/^([01]?\d|2[0-3]):([0-5]\d)$/);
  if (!match) return "";
  const hh = String(match[1]).padStart(2, "0");
  return `${hh}:${match[2]}`;
}

function isScheduleActive(schedule) {
  if (!schedule?.enabled || !schedule?.selected?.length) return false;

  const start = parseClockToMinutes(schedule.start);
  const end = parseClockToMinutes(schedule.end);
  if (start < 0 || end < 0) return false;

  const now = new Date();
  const current = now.getHours() * 60 + now.getMinutes();

  if (start <= end) {
    return current >= start && current <= end;
  }

  return current >= start || current <= end;
}

function parseClockToMinutes(value) {
  const match = String(value || "").match(/^(\d{2}):(\d{2})$/);
  if (!match) return -1;
  return Number(match[1]) * 60 + Number(match[2]);
}

function writeConfig(config) {
  fs.mkdirSync(path.dirname(IA_CONFIG_FILE), { recursive: true });
  fs.writeFileSync(IA_CONFIG_FILE, JSON.stringify(config, null, 2));
}

module.exports = {
  adaptAnswerToPersonality,
  buildIaSystemPrompt,
  getIaConfig,
  getIaPersonalityLabel,
  saveIaConfig
};
