"use strict";

const fs = require("fs");
const path = require("path");

const { loadEnv } = require("./env");

loadEnv();

const DATA_DIR = process.env.DATA_DIR || path.join(process.cwd(), "data");
const ADMINS_FILE = process.env.ADMINS_FILE || path.join(DATA_DIR, "admins.json");

function getAdmins() {
  return readAdmins().sort((a, b) => String(a.name || a.jid).localeCompare(String(b.name || b.jid), "pt-BR"));
}

function addAdmin({ jid, phone, name }) {
  const normalizedJid = normalizeAdminJid(jid || phone);

  if (!normalizedJid) {
    throw new Error("Informe um telefone ou JID valido.");
  }

  const admins = readAdmins();
  const index = admins.findIndex((admin) => admin.jid === normalizedJid);
  const item = {
    jid: normalizedJid,
    phone: extractPhone(normalizedJid),
    name: String(name || "").trim() || extractPhone(normalizedJid) || normalizedJid,
    updatedAt: new Date().toISOString()
  };

  if (index === -1) {
    item.createdAt = item.updatedAt;
    admins.push(item);
  } else {
    admins[index] = {
      ...admins[index],
      ...item
    };
  }

  writeAdmins(admins);
  return item;
}

function removeAdmin(jid) {
  const normalizedJid = normalizeAdminJid(jid);
  const admins = readAdmins();
  const next = admins.filter((admin) => admin.jid !== normalizedJid);

  writeAdmins(next);
  return admins.length !== next.length;
}

function isAdminJid(jid) {
  const normalizedJid = normalizeAdminJid(jid);
  if (!normalizedJid) return false;

  return readAdmins().some((admin) => admin.jid === normalizedJid);
}

function getMessageSenderJid(msg) {
  return normalizeAdminJid(msg?.key?.participant || msg?.participant || msg?.key?.remoteJid);
}

function normalizeAdminJid(value) {
  const raw = String(value || "").trim().toLowerCase();
  if (!raw) return "";

  if (raw.includes("@")) {
    const [user, server] = raw.split("@");
    const cleanUser = user.split(":")[0].replace(/[^\w.-]/g, "");
    const cleanServer = (server || "s.whatsapp.net").split(":")[0];

    if (!cleanUser || !cleanServer) return "";
    return `${cleanUser}@${cleanServer}`;
  }

  const digits = raw.replace(/\D/g, "");
  if (digits.length < 10) return "";

  return `${digits}@s.whatsapp.net`;
}

function extractPhone(jid) {
  const user = String(jid || "").split("@")[0] || "";
  return /^\d+$/.test(user) ? user : "";
}

function readAdmins() {
  try {
    const data = JSON.parse(fs.readFileSync(ADMINS_FILE, "utf8"));
    return Array.isArray(data) ? data : [];
  } catch (error) {
    return [];
  }
}

function writeAdmins(admins) {
  fs.mkdirSync(path.dirname(ADMINS_FILE), { recursive: true });
  fs.writeFileSync(ADMINS_FILE, JSON.stringify(admins, null, 2));
}

module.exports = {
  addAdmin,
  getAdmins,
  getMessageSenderJid,
  isAdminJid,
  normalizeAdminJid,
  removeAdmin
};
