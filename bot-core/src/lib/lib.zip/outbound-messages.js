"use strict";

const fs = require("fs");
const path = require("path");

const { loadEnv } = require("./env");
const { findInboundMessage } = require("./inbound-messages");

loadEnv();

const DATA_DIR = process.env.DATA_DIR || path.join(process.cwd(), "data");
const OUTBOX_FILE = process.env.OUTBOX_FILE || path.join(DATA_DIR, "outbox.json");
const OUTBOX_INTERVAL_MS = Number(process.env.OUTBOX_INTERVAL_MS || 3000);
const MAX_OUTBOX_ITEMS = Number(process.env.MAX_OUTBOX_ITEMS || 300);
const OUTBOX_MAX_RETRIES = Number(process.env.OUTBOX_MAX_RETRIES || 10);
const OUTBOX_RETRY_DELAY_MS = Number(process.env.OUTBOX_RETRY_DELAY_MS || 8000);

let processing = false;
let interval = null;

function enqueueOutboundMessage({ jid, groupName, text, replyToId = null, source = "web" }) {
  const cleanJid = String(jid || "").trim();
  const cleanText = String(text || "").trim();

  if (!cleanJid.endsWith("@g.us")) {
    throw new Error("Selecione um grupo valido.");
  }

  if (!cleanText) {
    throw new Error("Digite uma mensagem.");
  }

  const queue = readOutbox();
  const item = {
    id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
    jid: cleanJid,
    groupName: String(groupName || cleanJid).trim(),
    text: cleanText,
    replyToId: replyToId ? String(replyToId).trim() : null,
    source,
    status: "queued",
    retryCount: 0,
    nextAttemptAt: null,
    createdAt: new Date().toISOString(),
    sentAt: null,
    error: null
  };

  queue.unshift(item);
  writeOutbox(queue.slice(0, MAX_OUTBOX_ITEMS));

  return item;
}

function startOutboundProcessor(sock) {
  if (interval) return;

  interval = setInterval(() => {
    processOutboundMessages(sock).catch((error) => {
      console.error("Erro ao processar outbox:", error.message);
    });
  }, OUTBOX_INTERVAL_MS);

  setTimeout(() => {
    processOutboundMessages(sock).catch((error) => {
      console.error("Erro ao processar outbox:", error.message);
    });
  }, 1500);
}

async function processOutboundMessages(sock) {
  if (processing) return;
  processing = true;

  try {
    const queue = readOutbox();
    const now = Date.now();
    const pending = queue
      .filter((item) => {
        const status = String(item.status || "");
        const retryCount = Number(item.retryCount || 0);
        const nextAt = item.nextAttemptAt ? new Date(item.nextAttemptAt).getTime() : 0;
        const due = !nextAt || nextAt <= now;
        if (status === "queued") return due;
        if (status === "error" && retryCount < OUTBOX_MAX_RETRIES && due) return true;
        return false;
      })
      .sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt))
      .slice(0, 10);

    for (const item of pending) {
      try {
        const quoted = item.replyToId ? findInboundMessage(item.replyToId) : null;
        await sock.sendMessage(
          item.jid,
          { text: formatBoldMessage(item.text) },
          quoted ? { quoted } : undefined
        );
        updateOutboxItem(item.id, {
          status: "sent",
          sentAt: new Date().toISOString(),
          retryCount: 0,
          nextAttemptAt: null,
          error: null
        });
        console.log(`Mensagem web enviada jid=${item.jid} grupo=${item.groupName}`);
      } catch (error) {
        const retryCount = Number(item.retryCount || 0) + 1;
        if (isTransientConnectionError(error) && retryCount <= OUTBOX_MAX_RETRIES) {
          updateOutboxItem(item.id, {
            status: "queued",
            retryCount,
            nextAttemptAt: new Date(Date.now() + OUTBOX_RETRY_DELAY_MS * Math.min(retryCount, 6)).toISOString(),
            error: error.message
          });
        } else {
          updateOutboxItem(item.id, {
            status: "error",
            retryCount,
            nextAttemptAt: null,
            error: error.message
          });
        }
        console.error(`Falha ao enviar mensagem web jid=${item.jid}:`, error.message);
      }
    }
  } finally {
    processing = false;
  }
}

function isTransientConnectionError(error) {
  const text = String(error?.message || error || "").toLowerCase();
  return text.includes("connection closed")
    || text.includes("not connected")
    || text.includes("timed out")
    || text.includes("connection terminated")
    || text.includes("ecconnreset")
    || text.includes("stream errored");
}

function getOutboundHistory(limit = 40) {
  return readOutbox().slice(0, limit);
}

function updateOutboxItem(id, update) {
  const queue = readOutbox();
  const index = queue.findIndex((item) => item.id === id);

  if (index === -1) return;

  queue[index] = {
    ...queue[index],
    ...update
  };
  writeOutbox(queue);
}

function formatBoldMessage(text) {
  return String(text || "")
    .split(/\r?\n/)
    .map((line) => {
      const cleanLine = line.trim();
      return cleanLine ? `*${cleanLine.replace(/\*/g, "")}*` : "";
    })
    .join("\n");
}

function readOutbox() {
  try {
    const data = JSON.parse(fs.readFileSync(OUTBOX_FILE, "utf8"));
    return Array.isArray(data) ? data : [];
  } catch (error) {
    return [];
  }
}

function writeOutbox(queue) {
  fs.mkdirSync(path.dirname(OUTBOX_FILE), { recursive: true });
  fs.writeFileSync(OUTBOX_FILE, JSON.stringify(queue, null, 2));
}

module.exports = {
  enqueueOutboundMessage,
  getOutboundHistory,
  startOutboundProcessor
};
